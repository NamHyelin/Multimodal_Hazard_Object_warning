# RSU Semantic Communication and Digital Twin

Read-only source snapshots collected on 2026-10-27 from the RSU (`honkan`) and digital twin (`DTServer`). Both servers are represented in this single repository. The copied application/source/configuration files retain their original bytes; per-file SHA-256 hashes are included.

## Layout

```text
honkan/
  hyelin/                         # Original applications plus the existing _rev copies
  src/                            # Existing Autoware / LiDAR / camera package source
  scripts/                        # Existing build, start, run and stop scripts
  config/                         # Existing configurations
  calibration/                    # Existing calibration files
  vendor/                         # Existing vendor headers; original notices retained
  deployed_centerpoint_share/     # Selected deployed CenterPoint package configuration
  models/                         # Small model configuration/label files; no weights
  compose.yaml
dt_server/
  dt_server.py
  dt_server_rev.py
  receiver.py
  T2I.py
  AR_background.jpg
  icons/
environments/
  honkan/
  dt_server/
```

The active research path uses LiDAR/CenterPoint, conditional Florence I2T and SANA-Sprint T2I. Archived YOLO-related files are included to preserve existing source; collecting them did not execute YOLO or change running services.

## Environment preservation

No packages were installed, removed or upgraded on either server during this export. No server Git repository was initialized. No VS Code settings or Python interpreter selections were changed. A separate Git repository was created only in the local export directory.

Each `environments/<server>/` directory contains:

- `inventory.json`: Python interpreter details and installed distribution metadata.
- `distributions.snapshot.txt`: the same observed distribution names and versions, for inspection.
- `runtime_import_versions.json`: versions and paths of the modules actually imported by that server's Python interpreter. The honkan check uses the existing ROS/Autoware environment script.
- `runtime_versions.reference.txt`: a short reference for important runtime versions.
- `source_manifest.json`: source origin, capture time, file sizes and SHA-256 hashes.
- `pyvenv.cfg.snapshot`: a read-only copy of virtual-environment metadata.
- OS, container-image or GPU-driver metadata.

The RSU exposes both virtual-environment and system package metadata, including duplicate distribution names with different versions. Consequently, **these inventories are records, not an instruction to run `pip install -r`**. Import versions and module paths distinguish the packages actually used. The RSU and DT have different GPU/platform builds; their environments must remain separate.

The `.venv` directories, installed binaries, container filesystem, model weights and road map data are not embedded. A Git clone therefore preserves code and version records, but does not reproduce an entire machine by itself. No automatic environment recreation, dependency update or setup hook is included.

## Running on the existing servers

The Python files intentionally retain their existing absolute paths. This is an archival snapshot; cloning it elsewhere does not rewrite deployment paths or replace the active files.

On honkan, use the existing container and environment:

```bash
docker exec -it tian_autoware_runtime bash
source /autoware_runtime/scripts/enter_autoware_runtime_bash/container_env.sh
cd /autoware_runtime/hyelin
source .venv/bin/activate
python -u centerpoint_florence_live_rev.py \
  --image_topic /rsu1/gate/image_raw \
  --camera_info_topic /rsu1/gate/camera_info \
  --pointcloud_topic /sensing/lidar/concatenated/pointcloud \
  --centerpoint_topic /perception/object_recognition/detection/centerpoint/objects \
  --confidence_threshold 0.4 --save_crops --warmup --allow_intrinsic_rescale \
  --receiver_ip 172.16.1.203 --receiver_port 8001 --dt_world_frame map \
  --max_saved_frames 500 --run_id UNIQUE_RUN_ID
```

On DTServer, use two terminals with the same unique run ID:

```bash
cd /home/morita/hyelin
source .venv/bin/activate
export SEMCOMM_RUN_ID=UNIQUE_RUN_ID
python -u dt_server_rev.py --receiver --host 0.0.0.0 --port 8001 \
  --exchange_dir /home/morita/hyelin/dt_exchange
```

```bash
cd /home/morita/hyelin
source .venv/bin/activate
export SEMCOMM_RUN_ID=UNIQUE_RUN_ID
python -u dt_server_rev.py
```

Check existing sensor services before starting them again. Preserve earlier results and use a new run ID. After 500 RSU frames, distinguish saved, sent, received and rendered counts because latest-only rendering can skip updates.

## Modification policy

Preserve the original Python files. Make future pipeline changes in the existing `honkan/hyelin/centerpoint_florence_live_rev.py` and `dt_server/dt_server_rev.py` only. Do not create a new numbered revision on each edit. No live experiment was launched as part of this export.

## Publication status

This local repository is prepared for the GitHub account `NamHyelin`; suggested repository name: `rsu-semantic-digital-twin`. **It has not been uploaded.** GitHub browser access was denied, and no alternate route was used. A private repository is recommended for the initial backup because this snapshot contains deployment paths, network configuration and project assets.

Credentials, virtual environments, VS Code settings and live experimental captures are excluded. Third-party source and vendor files retain their existing license notices; no new license is asserted for those files.
