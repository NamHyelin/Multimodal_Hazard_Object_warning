#!/usr/bin/env bash
set -euo pipefail

source /autoware_runtime/scripts/enter_autoware_runtime_bash/container_env.sh

model_dir=/autoware_runtime/models/lidar_centerpoint
required_files=(
  "${model_dir}/pts_voxel_encoder_centerpoint_tiny.engine"
  "${model_dir}/pts_backbone_neck_head_centerpoint_tiny.engine"
  "/autoware_runtime/install/autoware_lidar_centerpoint/lib/autoware_lidar_centerpoint/autoware_lidar_centerpoint_node"
  "/autoware_runtime/install/autoware_tensorrt_common/lib/libautoware_tensorrt_common.so"
)
for file in "${required_files[@]}"; do
  if [[ ! -f "${file}" ]]; then
    echo "Required CenterPoint asset is missing: ${file}" >&2
    exit 1
  fi
done

exec ros2 launch autoware_lidar_centerpoint lidar_centerpoint.launch.xml \
  input/pointcloud:=/sensing/lidar/concatenated/pointcloud \
  output/objects:=/perception/object_recognition/detection/centerpoint/objects \
  data_path:=/autoware_runtime/models \
  node_name:=lidar_centerpoint \
  model_name:=centerpoint_tiny \
  build_only:=false
