#!/usr/bin/env bash
set -euo pipefail

source /autoware_runtime/scripts/enter_autoware_runtime_bash/container_env.sh

pids=()
cleanup() {
  for pid in "${pids[@]:-}"; do
    kill "${pid}" 2>/dev/null || true
  done
  wait 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# Local, ground-referenced inference frame at the midpoint of RSU1 and RSU4.
ros2 run tf2_ros static_transform_publisher \
  --x -13468.72323285 --y -43711.87156900 --z 70.40000000 \
  --roll 0 --pitch 0 --yaw 0 \
  --frame-id map --child-frame-id lidar_fusion &
pids+=("$!")

ros2 run lidar_fusion_adapter strict_front_fusion_node \
  --ros-args -p sync_tolerance_sec:=0.035 -p output_frame:=lidar_fusion \
  -p centerpoint_max_hz:="${PERCEPTION_CENTERPOINT_HZ:-12.0}" &
pids+=("$!")

wait -n "${pids[@]}"
