#!/usr/bin/env bash
set -euo pipefail

source /autoware_runtime/scripts/enter_autoware_runtime_bash/container_env.sh

model_dir=/autoware_runtime/models/tensorrt_yolox
param_file=/autoware_runtime/install/autoware_tensorrt_yolox/share/autoware_tensorrt_yolox/config/yolox_tiny.param.yaml
required_files=(
  "${model_dir}/yolox-tiny.onnx"
  "${model_dir}/yolox-tiny.engine"
  "${model_dir}/label.txt"
  "${model_dir}/semseg_color_map.csv"
  "${param_file}"
  "/autoware_runtime/install/autoware_tensorrt_yolox/lib/autoware_tensorrt_yolox/autoware_tensorrt_yolox_node_exe"
  "/autoware_runtime/install/autoware_tensorrt_common/lib/libautoware_tensorrt_common.so"
)

for file in "${required_files[@]}"; do
  if [[ ! -e "${file}" ]]; then
    echo "Required YOLOX asset is missing: ${file}" >&2
    exit 1
  fi
done

common_args=(
  yolox_param_path:="${param_file}"
  model_path:="${model_dir}/yolox-tiny.onnx"
  label_path:="${model_dir}/label.txt"
  semantic_segmentation_color_map_path:="${model_dir}/semseg_color_map.csv"
  use_decompress:=false
)

ros2 launch autoware_tensorrt_yolox yolox.launch.xml \
  yolox_node_name:=tensorrt_yolox_gate \
  input/image:=/rsu1/gate/image_raw \
  output/objects:=/rsu1/gate/yolox/objects \
  output/mask:=/rsu1/gate/yolox/mask \
  "${common_args[@]}" &
gate_pid=$!

ros2 launch autoware_tensorrt_yolox yolox.launch.xml \
  yolox_node_name:=tensorrt_yolox_intersection \
  input/image:=/rsu1/intersection/image_raw \
  output/objects:=/rsu1/intersection/yolox/objects \
  output/mask:=/rsu1/intersection/yolox/mask \
  "${common_args[@]}" &
intersection_pid=$!

cleanup()
{
  kill -TERM "${gate_pid}" "${intersection_pid}" 2>/dev/null || true
  wait "${gate_pid}" "${intersection_pid}" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

set +e
wait -n "${gate_pid}" "${intersection_pid}"
status=$?
set -e
echo "A YOLOX launch process exited with status ${status}; stopping both camera pipelines." >&2
exit "${status}"
