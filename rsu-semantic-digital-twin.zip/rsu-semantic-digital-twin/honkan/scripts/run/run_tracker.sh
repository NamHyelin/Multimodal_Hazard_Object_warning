#!/usr/bin/env bash
set -euo pipefail

source /autoware_runtime/scripts/enter_autoware_runtime_bash/container_env.sh

exec ros2 launch autoware_multi_object_tracker multi_object_tracker.launch.xml \
  input/detection01/objects:=/perception/object_recognition/detection/centerpoint/objects \
  input/detection01/channel:=lidar_centerpoint \
  output/objects:=/perception/object_recognition/tracking/objects \
  output/merged_objects:=/perception/object_recognition/tracking/merged_objects \
  publish_merged_objects:=false \
  ego_source:=tf
