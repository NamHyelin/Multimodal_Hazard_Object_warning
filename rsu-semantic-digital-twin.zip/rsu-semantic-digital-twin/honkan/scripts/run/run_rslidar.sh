#!/usr/bin/env bash
set -eo pipefail

cd /autoware_runtime
set +u
source /opt/ros/humble/setup.bash
source /opt/autoware/setup.bash
source /autoware_runtime/install/setup.bash
set -u

PIDS=()

cleanup() {
  trap - EXIT INT TERM
  if [ "${#PIDS[@]}" -gt 0 ]; then
    kill -TERM "${PIDS[@]}" 2>/dev/null || true
    wait "${PIDS[@]}" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

ros2 run tf2_ros static_transform_publisher \
  --x 0 --y 0 --z 0 \
  --roll 0 --pitch 0 --yaw 0 \
  --frame-id map --child-frame-id base_link &
PIDS+=("$!")

ros2 run tf2_ros static_transform_publisher \
  --x -13493.5839410 --y -43708.8589474 --z 73.3625841 \
  --qx 0.002952810357 --qy -0.002084797726 \
  --qz -0.945946929740 --qw 0.324301311504 \
  --frame-id base_link --child-frame-id rsu1/rslidar &
PIDS+=("$!")

ros2 run tf2_ros static_transform_publisher \
  --x -13443.8625247 --y -43714.8841906 --z 72.9191512 \
  --qx -0.002474278549 --qy 0.005381392192 \
  --qz 0.999474766800 --qw 0.031860789841 \
  --frame-id base_link --child-frame-id rsu4/rslidar &
PIDS+=("$!")

ros2 launch rslidar_sdk start.py &
PIDS+=("$!")

set +e
wait -n "${PIDS[@]}"
STATUS=$?
set -e
exit "${STATUS}"
