#!/usr/bin/env bash
set -euo pipefail
docker exec tian_autoware_runtime bash -lc '
  set -eo pipefail
  source /opt/ros/humble/setup.bash
  source /opt/autoware/setup.bash
  cd /autoware_runtime
  colcon --log-base log/transport_upgrade_20261017 build \
    --base-paths src --symlink-install \
    --build-base build/transport_upgrade_20261017 \
    --install-base install/transport_upgrade_20261017 \
    --packages-select camera_mjpeg_receiver lidar_fusion_adapter \
    --cmake-args -DCMAKE_BUILD_TYPE=Release
'
