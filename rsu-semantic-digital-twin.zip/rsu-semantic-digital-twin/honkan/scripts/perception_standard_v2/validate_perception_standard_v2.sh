#!/usr/bin/env bash
set -euo pipefail

container=tian_autoware_runtime
run_hz() {
  local topic="$1"
  echo "=== ${topic} ==="
  docker exec "${container}" bash -lc \
    "source /autoware_runtime/scripts/perception_standard_v2/env.sh >/dev/null 2>&1; timeout 12 ros2 topic hz '${topic}' --window 50 || true"
}

run_hz /sensing/lidar/concatenated/pointcloud
run_hz /perception/object_recognition/detection/centerpoint/objects
run_hz /perception/object_recognition/tracking/objects
run_hz /rsu1/gate/yolo26s/objects
run_hz /rsu1/intersection/yolo26s/objects
