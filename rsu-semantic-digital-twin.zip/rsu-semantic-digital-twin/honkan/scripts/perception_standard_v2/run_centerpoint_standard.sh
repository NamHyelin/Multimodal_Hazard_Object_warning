#!/usr/bin/env bash
set -euo pipefail
source /autoware_runtime/scripts/perception_standard_v2/env.sh

model_dir="${PSV2_MODELS}/lidar_centerpoint"
exec ros2 launch autoware_lidar_centerpoint lidar_centerpoint.launch.xml \
  input/pointcloud:="${PSV2_CENTERPOINT_INPUT_TOPIC:-${PSV2_POINTCLOUD_TOPIC}}" \
  output/objects:="${PSV2_CENTERPOINT_TOPIC}" \
  node_name:=lidar_centerpoint_standard \
  model_name:=centerpoint \
  model_path:="${model_dir}" \
  model_param_path:="${PSV2_CONFIG}/centerpoint_standard.param.yaml" \
  ml_package_param_path:="${model_dir}/centerpoint_ml_package.param.yaml" \
  class_remapper_param_path:="${model_dir}/detection_class_remapper.param.yaml" \
  build_only:=false
