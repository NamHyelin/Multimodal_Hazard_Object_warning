#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
runtime_dir="$(cd -- "${script_dir}/../.." && pwd)"
container=tian_autoware_runtime
cd "${runtime_dir}"

# Fail before stopping a working pipeline if the host lost its required limits.
for key in net.core.rmem_max net.core.wmem_max; do
  if [[ "$(sysctl -n "${key}")" -lt 16777216 ]]; then
    echo "${key} is too small. Apply config/perception_transport.sysctl.conf on the host." >&2
    exit 1
  fi
done

required=(
  install/perception_standard_v2/setup.bash
  install/transport_upgrade_20261017/local_setup.bash
  models/perception_standard_v2/lidar_centerpoint/pts_voxel_encoder_centerpoint.engine
  models/perception_standard_v2/lidar_centerpoint/pts_backbone_neck_head_centerpoint.engine
  models/perception_standard_v2/yolo26s/yolo26s_autoware.engine
  models/perception_standard_v2/yolo26s/coco80_labels.txt
  models/perception_standard_v2/yolo26s/coco80_to_autoware.csv
)
for file in "${required[@]}"; do
  [[ -s "${file}" ]] || { echo "Missing V2 asset: ${runtime_dir}/${file}" >&2; exit 1; }
done

echo "Stopping previous perception pipeline..."
# Include existing V2 nodes so repeated start cannot create duplicate inference.
bash "${script_dir}/stop_perception_standard_v2.sh" >/dev/null
scripts/stop/stop_yolox.sh >/dev/null || true
scripts/stop/stop_tracker.sh >/dev/null || true
scripts/stop/stop_centerpoint.sh >/dev/null || true
scripts/stop/stop_camera_receiver.sh >/dev/null || true
if docker inspect -f '{{.State.Running}}' "${container}" 2>/dev/null | grep -qx true; then
  docker exec "${container}" bash -lc \
    "pkill -TERM -f '[s]trict_front_fusion_node' || true; pkill -TERM -f '[s]tatic_transform_publisher.*lidar_fusion' || true; pkill -TERM -f '[r]un_lidar_fusion.sh' || true"
fi
docker compose stop rslidar >/dev/null 2>&1 || true
sleep 2

docker compose up -d autoware_runtime rslidar
scripts/start/start_camera_receiver.sh
scripts/start/start_lidar_fusion.sh

docker exec -d "${container}" bash -lc \
  'exec /autoware_runtime/scripts/perception_standard_v2/run_centerpoint_standard.sh >> /autoware_runtime/logs/perception_standard_v2/centerpoint_standard.log 2>&1'
for _ in $(seq 1 30); do
  if docker exec "${container}" bash -lc \
    "source /autoware_runtime/scripts/perception_standard_v2/env.sh >/dev/null 2>&1; ros2 node list 2>/dev/null | grep -qx /lidar_centerpoint_standard"; then
    break
  fi
  sleep 1
done
docker exec "${container}" bash -lc \
  "source /autoware_runtime/scripts/perception_standard_v2/env.sh >/dev/null 2>&1; ros2 node list 2>/dev/null | grep -qx /lidar_centerpoint_standard" || {
    echo "Standard CenterPoint failed to start" >&2; exit 1;
  }

docker exec -d "${container}" bash -lc \
  'exec /autoware_runtime/scripts/perception_standard_v2/run_tracker_standard.sh >> /autoware_runtime/logs/perception_standard_v2/tracker_standard.log 2>&1'
for _ in $(seq 1 30); do
  if docker exec "${container}" bash -lc \
    "source /autoware_runtime/scripts/perception_standard_v2/env.sh >/dev/null 2>&1; ros2 node list 2>/dev/null | grep -qx /multi_object_tracker"; then
    break
  fi
  sleep 1
done
docker exec "${container}" bash -lc \
  "source /autoware_runtime/scripts/perception_standard_v2/env.sh >/dev/null 2>&1; ros2 node list 2>/dev/null | grep -qx /multi_object_tracker" || {
    echo "Tracker failed to start" >&2; exit 1;
  }

docker exec -d "${container}" bash -lc \
  'exec /autoware_runtime/scripts/perception_standard_v2/run_yolo26s_dual.sh >> /autoware_runtime/logs/perception_standard_v2/yolo26s_dual.log 2>&1'
for _ in $(seq 1 30); do
  count=$(docker exec "${container}" bash -lc \
    "source /autoware_runtime/scripts/perception_standard_v2/env.sh >/dev/null 2>&1; ros2 node list 2>/dev/null | grep -Ec '^/tensorrt_yolo26s_(gate|intersection)$'" || true)
  [[ "${count}" -eq 2 ]] && break
  sleep 1
done
count=$(docker exec "${container}" bash -lc \
  "source /autoware_runtime/scripts/perception_standard_v2/env.sh >/dev/null 2>&1; ros2 node list 2>/dev/null | grep -Ec '^/tensorrt_yolo26s_(gate|intersection)$'" || true)
[[ "${count}" -eq 2 ]] || { echo "Dual YOLO26s failed to start" >&2; exit 1; }

"${script_dir}/status_perception_standard_v2.sh"
echo "Perception Standard V2 started."
