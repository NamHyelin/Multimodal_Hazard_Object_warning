#!/usr/bin/env python3
"""Read-only simultaneous small-topic/MJPEG/socket-loss capacity measurement."""
import argparse
import collections
import datetime
import json
import os
from pathlib import Path
import statistics
import threading
import time
import urllib.request

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from autoware_perception_msgs.msg import DetectedObjects, TrackedObjects
from autoware_internal_debug_msgs.msg import Float64Stamped
from sensor_msgs.msg import CameraInfo
from tier4_perception_msgs.msg import DetectedObjectsWithFeature


def summary(values):
    if not values:
        return None
    values = sorted(values)
    return dict(mean=round(statistics.mean(values), 2), median=round(statistics.median(values), 2),
                p95=round(values[int((len(values) - 1) * .95)], 2), max=round(values[-1], 2))


def socket_drops():
    sockets = {}
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():
            continue
        try:
            cmd = (process / 'cmdline').read_bytes().replace(b'\0', b' ').decode()
            if cmd.startswith('python3 -u /autoware_runtime/scripts/perception_web_monitor/monitor.py'):
                name = 'web_monitor'
            elif cmd.startswith('/autoware_runtime/install/') and 'autoware_tensorrt_yolox_node_exe' in cmd:
                name = 'yolo_gate' if '__node:=tensorrt_yolo26s_gate' in cmd else 'yolo_intersection'
            elif cmd.startswith('/autoware_runtime/install/') and '/strict_front_fusion_node' in cmd:
                name = 'lidar_fusion'
            elif cmd.startswith('/autoware_runtime/install/') and '/autoware_lidar_centerpoint_node' in cmd:
                name = 'centerpoint'
            elif cmd.startswith('/autoware_runtime/install/') and '/camera_mjpeg_receiver_node' in cmd:
                name = 'camera_receiver'
            else:
                continue
            for fd in (process / 'fd').iterdir():
                try:
                    link = os.readlink(fd)
                except OSError:
                    continue
                if link.startswith('socket:['):
                    sockets[link[8:-1]] = name
        except (OSError, UnicodeError):
            continue
    result = collections.defaultdict(int)
    for line in Path('/proc/net/udp').read_text().splitlines()[1:]:
        fields = line.split()
        if fields[9] in sockets:
            result[sockets[fields[9]]] += int(fields[-1])
    return dict(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seconds', type=float, default=30)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.seconds <= 0:
        parser.error('--seconds must be positive')
    rclpy.init()
    node = Node('perception_transport_measurement')
    arrivals, ages, metrics = collections.defaultdict(list), collections.defaultdict(list), collections.defaultdict(list)
    subscriptions = []
    topics = [('/perception/object_recognition/detection/centerpoint/objects', DetectedObjects),
              ('/perception/object_recognition/tracking/objects', TrackedObjects)]
    for name in ('gate', 'intersection'):
        topics.extend([(f'/rsu1/{name}/yolo26s/objects', DetectedObjectsWithFeature),
                       (f'/rsu1/{name}/camera_info', CameraInfo)])
    for topic, cls in topics:
        def receive(msg, topic=topic):
            stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
            arrivals[topic].append(time.monotonic())
            ages[topic].append((node.get_clock().now().nanoseconds * 1e-9 - stamp) * 1000)
        subscriptions.append(node.create_subscription(cls, topic, receive, qos_profile_sensor_data))
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=.05)
    for topic, types in node.get_topic_names_and_types():
        if ('processing_time_ms' in topic or 'pipeline_latency_ms' in topic) and 'autoware_internal_debug_msgs/msg/Float64Stamped' in types:
            subscriptions.append(node.create_subscription(Float64Stamped, topic,
                lambda msg, topic=topic: metrics[topic].append(float(msg.data)), qos_profile_sensor_data))
    arrivals.clear()
    ages.clear()
    base = 'http://127.0.0.1:8088'
    def status():
        with urllib.request.urlopen(base + '/api/status', timeout=3) as response:
            return json.load(response)
    initial_status, before = status(), socket_drops()
    end = time.monotonic() + args.seconds
    streams = {}
    def stream(name):
        times = []
        try:
            with urllib.request.urlopen(base + f'/stream/{name}.mjpg', timeout=3) as response:
                while time.monotonic() < end:
                    line = response.readline()
                    if not line:
                        raise EOFError('MJPEG stream closed')
                    if not line.startswith(b'--frame'):
                        continue
                    length = 0
                    while True:
                        line = response.readline()
                        if line in (b'\r\n', b'\n', b''):
                            break
                        if line.lower().startswith(b'content-length:'):
                            length = int(line.split(b':', 1)[1])
                    if not 4 <= length <= 4_000_000 or len(response.read(length)) != length:
                        raise ValueError('Invalid or truncated MJPEG frame')
                    times.append(time.monotonic())
            streams[name] = {'frames': len(times),
                'fps': round((len(times) - 1) / (times[-1] - times[0]), 2) if len(times) > 1 else 0,
                'gap_ms': summary([1000 * (b - a) for a, b in zip(times, times[1:])])}
        except Exception as exc:
            streams[name] = {'error': str(exc), 'frames': len(times)}
    threads = [threading.Thread(target=stream, args=(name,)) for name in ('gate', 'intersection')]
    start = time.monotonic()
    for thread in threads:
        thread.start()
    try:
        while time.monotonic() < end:
            rclpy.spin_once(node, timeout_sec=.05)
        for thread in threads:
            thread.join(timeout=4)
        elapsed = time.monotonic() - start
        after, final_status = socket_drops(), status()
        results = {}
        for topic, _ in topics:
            times = arrivals[topic]
            results[topic] = {'messages': len(times),
                'hz': round((len(times) - 1) / (times[-1] - times[0]), 2) if len(times) > 1 else 0,
                'gap_ms': summary([1000 * (b - a) for a, b in zip(times, times[1:])]),
                'age_ms': summary(ages[topic])}
        result = {'measured_at': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),
                  'seconds': round(elapsed, 2), 'topics': results, 'metrics_ms': {t: summary(v) for t, v in metrics.items()},
                  'http_streams': streams, 'web_status': final_status,
                  'web_input_hz': {name: round((final_status[name]['received'] - initial_status[name]['received']) / elapsed, 2) for name in final_status},
                  'udp_socket_drop_increase': {name: count - before.get(name, count) for name, count in after.items()}}
        text = json.dumps(result, indent=2) + '\n'
        if args.output:
            args.output.write_text(text)
        print(text, flush=True)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
