#!/usr/bin/env bash
set -euo pipefail
source /autoware_runtime/scripts/perception_standard_v2/env.sh

exec ros2 launch autoware_multi_object_tracker multi_object_tracker.launch.xml \
  input/detection01/objects:="${PSV2_CENTERPOINT_TOPIC}" \
  input/detection01/channel:=lidar_centerpoint \
  output/objects:="${PSV2_TRACKING_TOPIC}" \
  output/merged_objects:=/perception/object_recognition/tracking/merged_objects \
  publish_merged_objects:=false \
  ego_source:=tf
