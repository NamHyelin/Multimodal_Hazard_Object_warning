#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
runtime_dir="$(cd -- "${script_dir}/../.." && pwd)"
"${script_dir}/stop_perception_standard_v2.sh"
"${runtime_dir}/scripts/start/start.sh"
echo "Legacy pipeline restored."
