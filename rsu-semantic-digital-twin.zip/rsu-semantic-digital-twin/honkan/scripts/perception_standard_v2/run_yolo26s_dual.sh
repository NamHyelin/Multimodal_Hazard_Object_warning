#!/usr/bin/env bash
set -euo pipefail
source /autoware_runtime/scripts/perception_standard_v2/env.sh

model_dir="${PSV2_MODELS}/yolo26s"
param_file="${PSV2_CONFIG}/yolo26s_standard.param.yaml"
exe="${PSV2_INSTALL}/autoware_tensorrt_yolox/lib/autoware_tensorrt_yolox/autoware_tensorrt_yolox_node_exe"
pids=()

cleanup() {
  kill -TERM "${pids[@]:-}" 2>/dev/null || true
  wait "${pids[@]:-}" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

"${exe}" --ros-args --params-file "${param_file}" \
  -p model_path:="${model_dir}/yolo26s_autoware.onnx" \
  -p label_path:="${model_dir}/coco80_labels.txt" \
  -p roi_remap_path:="${model_dir}/coco80_to_autoware.csv" \
  -r __node:=tensorrt_yolo26s_gate \
  -r "~/in/image:=${PSV2_GATE_IMAGE_TOPIC}" \
  -r "~/out/objects:=${PSV2_GATE_OBJECTS_TOPIC}" \
  -r "~/out/image:=/tensorrt_yolo26s_gate/out/image" &
pids+=("$!")

"${exe}" --ros-args --params-file "${param_file}" \
  -p model_path:="${model_dir}/yolo26s_autoware.onnx" \
  -p label_path:="${model_dir}/coco80_labels.txt" \
  -p roi_remap_path:="${model_dir}/coco80_to_autoware.csv" \
  -r __node:=tensorrt_yolo26s_intersection \
  -r "~/in/image:=${PSV2_INTERSECTION_IMAGE_TOPIC}" \
  -r "~/out/objects:=${PSV2_INTERSECTION_OBJECTS_TOPIC}" \
  -r "~/out/image:=/tensorrt_yolo26s_intersection/out/image" &
pids+=("$!")

set +e
wait -n "${pids[@]}"
status=$?
set -e
echo "A YOLO26s process exited with status ${status}; stopping both camera pipelines." >&2
exit "${status}"
