#!/usr/bin/env bash
set -euo pipefail

runtime_dir=/home/honkanmae/SSD/workspace/tian_ws/autoware_runtime
source_ws=/home/honkanmae/SSD/workspace/tian_ws/autoware
devel_container=tian-autoware-source-autoware-source-1

if ! docker inspect -f '{{.State.Running}}' "${devel_container}" 2>/dev/null | grep -qx true; then
  docker compose -f "${source_ws}/compose.yaml" up -d autoware-source
fi

docker exec "${devel_container}" bash -lc '
  set -eo pipefail
  source /opt/ros/humble/setup.bash
  source /opt/autoware/setup.bash
  cd /autoware_runtime
  mkdir -p build/perception_standard_v2 install/perception_standard_v2 log/perception_standard_v2

  colcon --log-base log/perception_standard_v2 build \
    --base-paths src --symlink-install \
    --build-base build/perception_standard_v2 \
    --install-base install/perception_standard_v2 \
    --packages-select autoware_tensorrt_common \
    --cmake-clean-cache --cmake-args -DCMAKE_BUILD_TYPE=Release \
      -DTENSORRT_ROOT=/opt/tensorrt-10.16 \
      -DTENSORRT_INCLUDE_DIR=/autoware_runtime/vendor/tensorrt-10.16/include \
      -DCMAKE_LIBRARY_PATH=/opt/tensorrt-10.16/lib

  source install/perception_standard_v2/setup.bash
  colcon --log-base log/perception_standard_v2 build \
    --base-paths src --symlink-install \
    --build-base build/perception_standard_v2 \
    --install-base install/perception_standard_v2 \
    --packages-select autoware_lidar_centerpoint \
    --cmake-clean-cache --cmake-args -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_LIBRARY_PATH=/opt/tensorrt-10.16/lib \
      -DNVINFER=/opt/tensorrt-10.16/lib/libnvinfer.so \
      -DNVONNXPARSER=/opt/tensorrt-10.16/lib/libnvonnxparser.so

  source install/perception_standard_v2/setup.bash
  colcon --log-base log/perception_standard_v2 build \
    --base-paths src --symlink-install \
    --build-base build/perception_standard_v2 \
    --install-base install/perception_standard_v2 \
    --packages-select autoware_tensorrt_yolox \
    --cmake-clean-cache --cmake-args -DCMAKE_BUILD_TYPE=Release \
      -DTENSORRT_ROOT=/opt/tensorrt-10.16 \
      -DTENSORRT_INCLUDE_DIR=/autoware_runtime/vendor/tensorrt-10.16/include \
      -DTENSORRT_NVINFER_LIBRARY=/opt/tensorrt-10.16/lib/libnvinfer.so \
      -DTENSORRT_NVINFER_PLUGIN_LIBRARY=/opt/tensorrt-10.16/lib/libnvinfer_plugin.so \
      -DTENSORRT_NVONNXPARSER_LIBRARY=/opt/tensorrt-10.16/lib/libnvonnxparser.so \
      -DCMAKE_LIBRARY_PATH=/opt/tensorrt-10.16/lib \
      -DNVINFER=/opt/tensorrt-10.16/lib/libnvinfer.so \
      -DNVONNXPARSER=/opt/tensorrt-10.16/lib/libnvonnxparser.so
'

echo "V2 packages built under ${runtime_dir}/install/perception_standard_v2"
