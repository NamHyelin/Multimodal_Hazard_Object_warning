# Perception Standard V2 commands

Run commands from the host.

## Start

    /home/honkanmae/SSD/workspace/tian_ws/autoware_runtime/scripts/perception_standard_v2/start_perception_standard_v2.sh

## Status

    /home/honkanmae/SSD/workspace/tian_ws/autoware_runtime/scripts/perception_standard_v2/status_perception_standard_v2.sh

## Validate topic rates

    /home/honkanmae/SSD/workspace/tian_ws/autoware_runtime/scripts/perception_standard_v2/validate_perception_standard_v2.sh

## Stop the complete V2 sensor and perception chain

    /home/honkanmae/SSD/workspace/tian_ws/autoware_runtime/scripts/perception_standard_v2/stop_perception_standard_v2.sh

## Roll back to the preserved legacy chain

    /home/honkanmae/SSD/workspace/tian_ws/autoware_runtime/scripts/perception_standard_v2/rollback_to_legacy.sh

## Rebuild packages

    /home/honkanmae/SSD/workspace/tian_ws/autoware_runtime/scripts/perception_standard_v2/build_packages.sh

## Rebuild engines

This stops legacy inference nodes before building and builds engines serially on the current Orin:

    /home/honkanmae/SSD/workspace/tian_ws/autoware_runtime/scripts/perception_standard_v2/build_engines.sh

Production assets are fixed under `/autoware_runtime/models/perception_standard_v2`; production scripts do not use `yolo_benchmark` or `yolox_debug`.
