#!/usr/bin/env bash
set -euo pipefail

set +u
source /opt/ros/humble/setup.bash
source /opt/autoware/setup.bash
source /autoware_runtime/config/perception_standard_v2/paths.env
source /autoware_runtime/config/perception_standard_v2/topics.env
if [[ ! -f "${PSV2_INSTALL}/setup.bash" ]]; then
  echo "Missing V2 overlay: ${PSV2_INSTALL}/setup.bash" >&2
  return 1 2>/dev/null || exit 1
fi
source "${PSV2_INSTALL}/setup.bash"
if [[ -f /autoware_runtime/config/transport_overlay.env ]]; then
  source /autoware_runtime/config/transport_overlay.env
  source "${PERCEPTION_TRANSPORT_OVERLAY}/local_setup.bash"
fi
set -u
export LD_LIBRARY_PATH="/usr/local/lib:${LD_LIBRARY_PATH:-}"
