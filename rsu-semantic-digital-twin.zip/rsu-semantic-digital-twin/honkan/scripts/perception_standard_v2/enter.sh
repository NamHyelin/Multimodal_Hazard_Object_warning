#!/usr/bin/env bash
set -euo pipefail

docker exec -it tian_autoware_runtime \
  bash --rcfile /autoware_runtime/scripts/perception_standard_v2/env.sh -i
