#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
runtime_dir="$(cd -- "${script_dir}/../.." && pwd)"
container=tian_autoware_runtime
cd "${runtime_dir}"

if docker inspect -f '{{.State.Running}}' "${container}" 2>/dev/null | grep -qx true; then
  docker exec "${container}" bash -lc \
    "pkill -TERM -f '[t]ensorrt_yolo26s_(gate|intersection)' || true; \
     pkill -TERM -f '^/autoware_runtime/install/perception_standard_v2/.*/autoware_tensorrt_yolox_node_exe' || true; \
     pkill -TERM -f '[r]un_yolo26s_dual.sh' || true; \
     pkill -TERM -f '[l]idar_centerpoint_standard' || true; \
     pkill -TERM -f '^/autoware_runtime/install/perception_standard_v2/.*/autoware_lidar_centerpoint_node' || true; \
     pkill -TERM -f '[r]un_centerpoint_standard.sh' || true; \
     pkill -TERM -f '[r]os2 launch autoware_multi_object_tracker multi_object_tracker.launch.xml' || true; \
     pkill -TERM -f '^/(opt/autoware|autoware_runtime/install)/.*/multi_object_tracker_node' || true; \
     pkill -TERM -f '[s]trict_front_fusion_node' || true; \
     pkill -TERM -f '[s]tatic_transform_publisher.*lidar_fusion' || true; \
     pkill -TERM -f '[r]un_lidar_fusion.sh' || true"
fi
scripts/stop/stop_camera_receiver.sh >/dev/null || true
docker compose stop rslidar >/dev/null 2>&1 || true
echo "Perception Standard V2 stopped. Legacy files were preserved."
