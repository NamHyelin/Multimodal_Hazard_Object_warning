#!/usr/bin/env bash
# Explicit application rollback. Retains larger host UDP limits and all evidence.
set -euo pipefail
runtime_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${runtime_dir}"
backup=plans/transport_upgrade_20261017/backup
for archive in config_source start_scripts inference_scripts; do
  [[ -s "${backup}/${archive}.tar.gz" ]] || { echo "Missing ${archive} backup" >&2; exit 1; }
done
bash scripts/perception_web_monitor/stop.sh
bash scripts/perception_standard_v2/stop_perception_standard_v2.sh
docker exec tian_autoware_runtime bash -lc '
  set -euo pipefail
  cd /autoware_runtime
  for archive in config_source start_scripts inference_scripts; do
    tar -xzf "plans/transport_upgrade_20261017/backup/${archive}.tar.gz"
  done
  if [[ -f config/transport_overlay.env ]]; then
    mv config/transport_overlay.env plans/transport_upgrade_20261017/backup/transport_overlay.disabled.env
  fi
'
bash scripts/perception_standard_v2/start_perception_standard_v2.sh
bash scripts/perception_web_monitor/start.sh
echo 'Application transport rolled back; evidence and 32 MiB host buffer limits retained.'
