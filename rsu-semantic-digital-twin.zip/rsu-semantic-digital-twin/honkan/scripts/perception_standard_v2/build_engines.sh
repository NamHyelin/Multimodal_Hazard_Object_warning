#!/usr/bin/env bash
set -euo pipefail

container=tian_autoware_runtime
runtime_dir=/home/honkanmae/SSD/workspace/tian_ws/autoware_runtime
cp_model=/autoware_runtime/models/perception_standard_v2/lidar_centerpoint
yolo_model=/autoware_runtime/models/perception_standard_v2/yolo26s
log_dir=/autoware_runtime/logs/perception_standard_v2

"${runtime_dir}/scripts/stop/stop_yolox.sh" >/dev/null
"${runtime_dir}/scripts/stop/stop_tracker.sh" >/dev/null
"${runtime_dir}/scripts/stop/stop_centerpoint.sh" >/dev/null

docker exec "${container}" bash -lc '
  set -euo pipefail
  source /autoware_runtime/scripts/perception_standard_v2/env.sh
  exec ros2 launch autoware_lidar_centerpoint lidar_centerpoint.launch.xml \
    input/pointcloud:=/sensing/lidar/concatenated/pointcloud \
    output/objects:=/perception_standard_v2/build/centerpoint/objects \
    node_name:=lidar_centerpoint_standard_builder \
    model_name:=centerpoint \
    model_path:='"${cp_model}"' \
    model_param_path:=/autoware_runtime/config/perception_standard_v2/centerpoint_standard.param.yaml \
    ml_package_param_path:='"${cp_model}"'/centerpoint_ml_package.param.yaml \
    class_remapper_param_path:='"${cp_model}"'/detection_class_remapper.param.yaml \
    build_only:=true
' > "${runtime_dir}/logs/perception_standard_v2/build_centerpoint_engine.log" 2>&1

docker exec "${container}" bash -lc '
  set -euo pipefail
  source /autoware_runtime/scripts/perception_standard_v2/env.sh
  exec "${PSV2_INSTALL}/autoware_tensorrt_yolox/lib/autoware_tensorrt_yolox/autoware_tensorrt_yolox_node_exe" \
    --ros-args \
    --params-file /autoware_runtime/config/perception_standard_v2/yolo26s_standard.param.yaml \
    -p model_path:='"${yolo_model}"'/yolo26s_autoware.onnx \
    -p label_path:='"${yolo_model}"'/coco80_labels.txt \
    -p roi_remap_path:='"${yolo_model}"'/coco80_to_autoware.csv \
    -p build_only:=true \
    -r __node:=tensorrt_yolo26s_builder
' > "${runtime_dir}/logs/perception_standard_v2/build_yolo26s_engine.log" 2>&1

required=(
  "${runtime_dir}/models/perception_standard_v2/lidar_centerpoint/pts_voxel_encoder_centerpoint.engine"
  "${runtime_dir}/models/perception_standard_v2/lidar_centerpoint/pts_backbone_neck_head_centerpoint.engine"
  "${runtime_dir}/models/perception_standard_v2/yolo26s/yolo26s_autoware.engine"
)
for file in "${required[@]}"; do
  [[ -s "${file}" ]] || { echo "Engine missing: ${file}" >&2; exit 1; }
done

record="${runtime_dir}/plans/perception_standard_v2/BUILD_RECORD.md"
{
  echo "# Perception Standard V2 build record"
  echo
  echo "- Built on: $(date --iso-8601=seconds)"
  echo "- TensorRT: 10.16.2"
  echo "- Container image: $(docker inspect -f '{{.Image}}' "${container}")"
  echo
  echo '## SHA-256'
  echo
  sha256sum \
    "${runtime_dir}/models/perception_standard_v2/lidar_centerpoint/"*.onnx \
    "${runtime_dir}/models/perception_standard_v2/lidar_centerpoint/"*.engine \
    "${runtime_dir}/models/perception_standard_v2/yolo26s/yolo26s_autoware.onnx" \
    "${runtime_dir}/models/perception_standard_v2/yolo26s/yolo26s_autoware.engine"
} > "${record}"

echo "V2 engines built and recorded in ${record}"
