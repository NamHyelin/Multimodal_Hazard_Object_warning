#!/usr/bin/env bash
set -euo pipefail

runtime_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${runtime_dir}"
docker compose ps autoware_runtime rslidar
docker exec tian_autoware_runtime bash -lc '
  source /autoware_runtime/scripts/perception_standard_v2/env.sh
  echo
  echo "V2 nodes:"
  ros2 node list | grep -E "^/(camera_mjpeg_receiver|strict_front_fusion|lidar_centerpoint_standard|multi_object_tracker|tensorrt_yolo26s_gate|tensorrt_yolo26s_intersection)$" || true
  echo
  for topic in \
    /sensing/lidar/concatenated/pointcloud \
    /perception/object_recognition/detection/centerpoint/objects \
    /perception/object_recognition/tracking/objects \
    /rsu1/gate/yolo26s/objects \
    /rsu1/intersection/yolo26s/objects; do
    echo "--- ${topic}"
    ros2 topic info "${topic}" || true
  done
  echo
  echo "Legacy detection publishers (expected absent):"
  ros2 topic info /rsu1/gate/yolox/objects 2>/dev/null || true
  ros2 topic info /rsu1/intersection/yolox/objects 2>/dev/null || true
  echo
  echo "V2 processes:"
  ps -eo pid,etime,pcpu,pmem,args | grep -E "(lidar_centerpoint_standard|tensorrt_yolo26s_|multi_object_tracker_node)" | grep -v grep || true
'
