// Copyright 2020 TIER IV, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "autoware/multi_object_tracker/tracker/trackers/pedestrian_and_bicycle_tracker.hpp"

namespace autoware::multi_object_tracker
{
PedestrianAndBicycleTracker::PedestrianAndBicycleTracker(
  const rclcpp::Time & time, const types::DynamicObject & object)
: Tracker(time, object),
  pedestrian_tracker_(time, object),
  bicycle_tracker_(object_model::bicycle, time, object)
{
  tracker_type_ = TrackerType::PEDESTRIAN_AND_BICYCLE;
}

bool PedestrianAndBicycleTracker::predict(const rclcpp::Time & time)
{
  pedestrian_tracker_.predict(time);
  bicycle_tracker_.predict(time);
  return true;
}

bool PedestrianAndBicycleTracker::measure(
  const types::DynamicObject & object, const rclcpp::Time & time,
  const types::InputChannel & channel_info)
{
  pedestrian_tracker_.measure(object, time, channel_info);
  bicycle_tracker_.measure(object, time, channel_info);
  pedestrian_tracker_.setLatestMeasurementTime(time);
  bicycle_tracker_.setLatestMeasurementTime(time);

  return true;
}

bool PedestrianAndBicycleTracker::getTrackedObject(
  const rclcpp::Time & time, types::DynamicObject & object, const bool to_publish) const
{
  const auto label = getHighestProbLabel();

  if (label == classes::Label::BICYCLE || label == classes::Label::MOTORCYCLE) {
    bicycle_tracker_.getTrackedObject(time, object, to_publish);
  } else if (label == classes::Label::PEDESTRIAN) {
    pedestrian_tracker_.getTrackedObject(time, object, to_publish);
  } else {
    // If the label is others, use the bicycle tracker as a fallback
    bicycle_tracker_.getTrackedObject(time, object, to_publish);
  }
  object.uuid = uuid_;
  return true;
}

void PedestrianAndBicycleTracker::setOrientationAvailability(
  const types::OrientationAvailability & orientation_availability)
{
  pedestrian_tracker_.setOrientationAvailability(orientation_availability);
  bicycle_tracker_.setOrientationAvailability(orientation_availability);
}

}  // namespace autoware::multi_object_tracker
