// Copyright 2020 TIER IV, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "autoware/multi_object_tracker/tracker/trackers/tracker_base.hpp"

#include "autoware/multi_object_tracker/object_model/uuid.hpp"
#include "autoware/multi_object_tracker/types.hpp"

#include <autoware_utils_geometry/geometry.hpp>

#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>

namespace
{
float updateProbability(
  const float & prior, const float & true_positive, const float & false_positive,
  const bool clamp = true)
{
  float probability =
    (prior * true_positive) / (prior * true_positive + (1 - prior) * false_positive);

  if (clamp) {
    // Normalize the probability to [0.1, 0.999]
    constexpr float max_updated_probability = 0.999;
    constexpr float min_updated_probability = 0.100;
    probability = std::clamp(probability, min_updated_probability, max_updated_probability);
  }

  return probability;
}
float decayProbability(const float & prior, const float & delta_time)
{
  constexpr float minimum_probability = 0.001;
  const float decay_rate = log(0.5f) / 0.5f;  // half-life (50% decay) of 0.5s
  return std::max(prior * std::exp(decay_rate * delta_time), minimum_probability);
}
}  // namespace

namespace autoware::multi_object_tracker
{

Tracker::Tracker(const rclcpp::Time & time, const types::DynamicObject & detected_object)
: no_measurement_count_(0),
  total_no_measurement_count_(0),
  total_measurement_count_(1),
  last_update_with_measurement_time_(time),
  channel_index_(detected_object.channel_index),
  existence_probability_(detected_object.existence_probability),
  kinematics_(detected_object.kinematics),
  trust_extension_(detected_object.trust_extension)
{
  // Assign a persistent tracker UUID (separate from measurement UUIDs).
  uuid_ = object_model::generate_uuid();

  // Initialize existence probabilities
  total_existence_probability_ = 0.001;
  classification_ = detected_object.classification;
}

void Tracker::initializeExistenceProbabilities(
  const uint & channel_index, const float & existence_probability)
{
  // The initial existence probability is normalized to [0.1, 0.999]
  // to avoid the existence probability being too low or too high
  // and to avoid the existence probability being too close to 0 or 1
  constexpr float max_probability = 0.999;
  constexpr float min_probability = 0.100;
  const float clamped_existence_probability =
    std::clamp(existence_probability, min_probability, max_probability);

  // total existence probability
  total_existence_probability_ = clamped_existence_probability;

  // existence probability on each channel
  // if the existence probabilities are not initialized, initialize with the given channel index and
  // existence probability
  if (existence_probabilities_.empty()) {
    existence_probabilities_.push_back({channel_index, clamped_existence_probability});
    return;
  }

  bool found = false;
  for (auto & prob : existence_probabilities_) {
    if (prob.channel_index == channel_index) {
      prob.existence_probability = clamped_existence_probability;
      found = true;
      break;
    }
  }
  if (!found) {
    existence_probabilities_.push_back({channel_index, clamped_existence_probability});
  }
}

void Tracker::updateTotalExistenceProbability(const float & existence_probability)
{
  total_existence_probability_ =
    updateProbability(total_existence_probability_, existence_probability, 0.2);
}

void Tracker::mergeExistenceProbabilities(
  std::vector<types::ExistenceProbability> existence_probabilities)
{
  // existence probability on each channel
  for (const auto & new_prob : existence_probabilities) {
    bool found = false;
    for (auto & prob : existence_probabilities_) {
      if (prob.channel_index == new_prob.channel_index) {
        // take larger value
        prob.existence_probability =
          std::max(prob.existence_probability, new_prob.existence_probability);
        found = true;
        break;
      }
    }
    if (!found) {
      existence_probabilities_.push_back(new_prob);
    }
  }
}

bool Tracker::updateWithMeasurement(
  const types::DynamicObject & object, const rclcpp::Time & measurement_time,
  const types::InputChannel & channel_info, bool has_significant_shape_change)
{
  // Update existence probability
  {
    no_measurement_count_ = 0;
    ++total_measurement_count_;

    // existence probability on each channel
    const float delta_time =
      std::abs((measurement_time - last_update_with_measurement_time_).seconds());
    constexpr float probability_true_detection = 0.9;
    constexpr float probability_false_detection = 0.2;

    // update measured channel probability without decay
    const uint & channel_index = channel_info.index;
    bool found = false;
    for (auto & prob : existence_probabilities_) {
      if (prob.channel_index == channel_index) {
        prob.existence_probability = updateProbability(
          prob.existence_probability, probability_true_detection, probability_false_detection);
        found = true;
        break;
      }
    }
    if (!found) {
      // If the channel is not found, add it with initial probability 0.001
      float new_prob =
        updateProbability(0.001f, probability_true_detection, probability_false_detection);
      existence_probabilities_.push_back({channel_index, new_prob});
    }

    // decay other channel probabilities
    for (auto & prob : existence_probabilities_) {
      if (prob.channel_index != channel_index) {
        prob.existence_probability = decayProbability(prob.existence_probability, delta_time);
      }
    }

    // update total existence probability
    total_existence_probability_ = updateProbability(
      total_existence_probability_, object.existence_probability * probability_true_detection,
      probability_false_detection);
  }

  last_update_with_measurement_time_ = measurement_time;

  // Update classification
  if (
    channel_info.trust_classification &&
    classes::getHighestProbLabel(object.classification) != classes::Label::UNKNOWN) {
    updateClassification(object.classification);
  }

  // Update orientation availability
  if (object.kinematics.orientation_availability == types::OrientationAvailability::AVAILABLE) {
    // if the incoming object is AVAILABLE, set the orientation availability to AVAILABLE
    kinematics_.orientation_availability = types::OrientationAvailability::AVAILABLE;
  } else if (
    object.kinematics.orientation_availability == types::OrientationAvailability::SIGN_UNKNOWN &&
    kinematics_.orientation_availability == types::OrientationAvailability::UNAVAILABLE) {
    // if the incoming object is SIGN_UNKNOWN and the tracker is UNAVAILABLE, set the orientation
    // availability to SIGN_UNKNOWN
    kinematics_.orientation_availability = types::OrientationAvailability::SIGN_UNKNOWN;
  }
  setOrientationAvailability(kinematics_.orientation_availability);

  // Select update path: NORMAL / TRY_EXTENSION / CONDITIONED
  const UpdatePath path =
    selectUpdatePath(channel_info.trust_extension, has_significant_shape_change);

  if (path == UpdatePath::NORMAL) {
    unstable_shape_filter_.processNormalMeasurement(object);
    measure(object, measurement_time, channel_info);
    trust_extension_ = object.trust_extension;

  } else if (path == UpdatePath::TRY_EXTENSION) {
    unstable_shape_filter_.processNoisyMeasurement(object);
    if (unstable_shape_filter_.isStable()) {
      // Extension update: apply stabilized shape and update with smoothed measurement
      const auto smoothed_shape = unstable_shape_filter_.getShape();
      setObjectShape(smoothed_shape);
      auto smoothed_object = object;
      smoothed_object.shape = smoothed_shape;
      measure(smoothed_object, measurement_time, channel_info);
      trust_extension_ = smoothed_object.trust_extension;
      unstable_shape_filter_.clear();
    } else {
      // Filter not yet stable — fall back to conditioned update.
      // The current (assembled) shape serves as the conditioned-update reference shape.
      types::DynamicObject predicted_object;
      getTrackedObject(measurement_time, predicted_object);
      conditionedUpdate(object, predicted_object, measurement_time, channel_info);
    }

  } else {  // UpdatePath::CONDITIONED
    types::DynamicObject predicted_object;
    getTrackedObject(measurement_time, predicted_object);
    conditionedUpdate(object, predicted_object, measurement_time, channel_info);
  }

  return true;
}

bool Tracker::updateWithoutMeasurement(const rclcpp::Time & timestamp)
{
  // Update existence probability
  ++no_measurement_count_;
  ++total_no_measurement_count_;
  {
    // decay existence probability
    float const delta_time = (timestamp - last_update_with_measurement_time_).seconds();
    for (auto & prob : existence_probabilities_) {
      prob.existence_probability = decayProbability(prob.existence_probability, delta_time);
    }
    total_existence_probability_ = decayProbability(total_existence_probability_, delta_time);
  }

  return true;
}

void Tracker::updateClassification(const std::vector<classes::Classification> & input)
{
  // classification algorithm:
  // 1. Update the matched classification probability
  // 2. If the label is not found, add it to the classification list
  // 3. Normalize tracking classification

  // If no existing classification, initialize with input
  if (classification_.empty()) {
    classification_ = input;
    return;
  }

  // Process existing classes
  for (auto & a_class : classification_) {
    // Find corresponding measurement
    auto it = std::find_if(input.begin(), input.end(), [&a_class](const auto & new_class) {
      return new_class.label == a_class.label;
    });

    if (it != input.end()) {
      // Class found in measurement
      constexpr float true_positive_rate = 0.8f;
      constexpr float false_positive_rate = 0.2f;
      a_class.probability = updateProbability(
        a_class.probability, it->probability * true_positive_rate, false_positive_rate);
    } else {
      // Class not observed in measurement
      constexpr float false_negative_rate = 0.6f;
      constexpr float true_negative_rate = 0.8f;
      constexpr float true_positive_rate = 1.0f - false_negative_rate;
      constexpr float false_positive_rate = 1.0f - true_negative_rate;
      a_class.probability =
        updateProbability(a_class.probability, true_positive_rate, false_positive_rate);
    }
  }

  // Add new classes from measurement that weren't in tracker
  for (const auto & new_class : input) {
    bool found = std::any_of(
      classification_.begin(), classification_.end(),
      [&new_class](const auto & old_class) { return old_class.label == new_class.label; });

    if (!found) {
      constexpr float true_positive_rate = 0.8f;
      auto adding_class = new_class;
      // New class gets probability weighted by measurement confidence
      adding_class.probability = new_class.probability * true_positive_rate;
      classification_.push_back(adding_class);
    }
  }

  // Normalization
  {
    float sum = 0.0;
    for (const auto & a_class : classification_) {
      sum += a_class.probability;
    }
    // Normalize only if the total probability is greater than 1.0
    if (sum > 1.0) {
      for (auto & a_class : classification_) {
        a_class.probability /= sum;
      }
    }
  }
}

uint Tracker::getChannelIndex() const
{
  // Return the index of the channel that has highest priority
  // lower the index, higher the priority

  uint index = 0;
  float max_probability = 0.0f;
  constexpr float threshold = 0.5;
  uint min_index_above_threshold = std::numeric_limits<uint>::max();

  for (const auto & prob : existence_probabilities_) {
    if (prob.existence_probability > threshold) {
      if (prob.channel_index < min_index_above_threshold) {
        min_index_above_threshold = prob.channel_index;
      }
    }
    if (prob.existence_probability > max_probability) {
      max_probability = prob.existence_probability;
      index = prob.channel_index;
    }
  }

  if (min_index_above_threshold != std::numeric_limits<uint>::max()) {
    return min_index_above_threshold;
  }
  // If no channel has a probability above the threshold, return the highest probability index
  return index;
}

void Tracker::getPositionCovarianceEigenSq(
  const rclcpp::Time & time, double & major_axis_sq, double & minor_axis_sq) const
{
  // estimate the covariance of the position at the given time, straight from the motion model
  // (single source of truth). getMotionState() clamps to the current state when `time` precedes
  // the last update, clamping to state time when queried in the past.
  geometry_msgs::msg::Pose pose;
  geometry_msgs::msg::Twist twist;
  std::array<double, 36> pose_cov{};
  std::array<double, 36> twist_cov{};
  if (!getMotionState(time, pose, pose_cov, twist, twist_cov)) {
    major_axis_sq = 0.0;
    minor_axis_sq = 0.0;
    return;
  }
  using autoware_utils_geometry::xyzrpy_covariance_index::XYZRPY_COV_IDX;

  // principal component of the position covariance matrix
  const double a = pose_cov[XYZRPY_COV_IDX::X_X];
  const double c = pose_cov[XYZRPY_COV_IDX::Y_Y];
  const double b = 0.5 * (pose_cov[XYZRPY_COV_IDX::X_Y] + pose_cov[XYZRPY_COV_IDX::Y_X]);

  Eigen::Matrix2d covariance;
  covariance << a, b, b, c;
  // check if the covariance is valid
  if (covariance(0, 0) <= 0.0 || covariance(1, 1) <= 0.0) {
    RCLCPP_WARN(
      rclcpp::get_logger("Tracker"), "Covariance is not valid. X_X: %f, Y_Y: %f", covariance(0, 0),
      covariance(1, 1));
    major_axis_sq = 0.0;
    minor_axis_sq = 0.0;
    return;
  }
  // Direct eigenvalue calculation for 2x2 symmetric matrix
  const double trace = a + c;
  const double det = a * c - b * b;

  double sqrt_arg = trace * trace / 4.0 - det;
  if (!std::isfinite(sqrt_arg)) {
    RCLCPP_WARN(
      rclcpp::get_logger("Tracker"),
      "Covariance eigen calc became invalid. trace: %f, det: %f, sqrt_arg: %f", trace, det,
      sqrt_arg);
    major_axis_sq = 0.0;
    minor_axis_sq = 0.0;
    return;
  }

  // Allow small negative values caused by floating-point round-off.
  constexpr double sqrt_arg_eps = 1e-12;
  if (sqrt_arg < -sqrt_arg_eps) {
    RCLCPP_WARN(
      rclcpp::get_logger("Tracker"),
      "Covariance eigen calc became invalid. trace: %f, det: %f, sqrt_arg: %f", trace, det,
      sqrt_arg);
    major_axis_sq = 0.0;
    minor_axis_sq = 0.0;
    return;
  }
  sqrt_arg = std::max(0.0, sqrt_arg);

  const double sqrt_term = std::sqrt(sqrt_arg);
  major_axis_sq = std::max(0.0, trace / 2.0 + sqrt_term);
  minor_axis_sq = std::max(0.0, trace / 2.0 - sqrt_term);
}

double Tracker::getBEVArea() const
{
  // Bird's-eye-view bounding area (length x width) of the current shape. Assembled from the shape
  // model rather than read from a stored shape; to_publish=false avoids any publish-time shape
  // conversion. Note this is intentionally the bbox-dimension product (used for adaptive gating),
  // which differs from getArea()/output.area (true area, used for association scoring).
  types::DynamicObject scratch;
  // Use the last measurement time so footprint freshness checks (which subtract ROS-clock times)
  // do not mix clock types with a default-constructed timestamp.
  scratch.time = getLatestMeasurementTime();
  assembleShapeTo(scratch, false);
  const auto & dims = scratch.shape.dimensions;
  return dims.x * dims.y;
}

double Tracker::getDistanceSqToEgo(const std::optional<geometry_msgs::msg::Pose> & ego_pose) const
{
  constexpr double INVALID_DISTANCE_SQ = -1.0;
  if (!ego_pose) {
    return INVALID_DISTANCE_SQ;
  }
  // Position is owned by the motion model; query it at the current state time.
  geometry_msgs::msg::Pose pose;
  geometry_msgs::msg::Twist twist;
  std::array<double, 36> pose_cov{};
  std::array<double, 36> twist_cov{};
  if (!getMotionState(getStateTime(), pose, pose_cov, twist, twist_cov)) {
    return INVALID_DISTANCE_SQ;
  }
  const auto & p = pose.position;
  const auto & e = ego_pose->position;
  const double dx = p.x - e.x;
  const double dy = p.y - e.y;
  return dx * dx + dy * dy;
}

double Tracker::computeAdaptiveThreshold(
  double base_threshold, double fallback_threshold, const AdaptiveThresholdCache & cache,
  const std::optional<geometry_msgs::msg::Pose> & ego_pose) const
{
  const double distance_sq = getDistanceSqToEgo(ego_pose);
  if (distance_sq < 0.0) return fallback_threshold;

  const double bev_area = getBEVArea();

  const double bev_area_influence = cache.getBEVAreaInfluence(bev_area);
  const double distance_influence = cache.getDistanceInfluence(distance_sq);

  return base_threshold + bev_area_influence + distance_influence;
}

bool Tracker::isConfident(
  const AdaptiveThresholdCache & cache, const std::optional<geometry_msgs::msg::Pose> & ego_pose,
  const std::optional<rclcpp::Time> & time = std::nullopt) const
{
  // check the number of measurements. if the measurement is too small, definitely not confident
  const int count = getTotalMeasurementCount();
  if (count < 2) {
    return false;
  }
  rclcpp::Time time_to_check;
  if (!time) {
    // add 200ms extrapolation time to the latest state time (motion model)
    // to consider the velocity uncertainty
    const rclcpp::Duration extrapolate_time = rclcpp::Duration::from_seconds(0.2);
    time_to_check = getStateTime() + extrapolate_time;
  } else {
    // use the given time
    time_to_check = *time;
  }

  double major_axis_sq = 0.0;
  double minor_axis_sq = 0.0;
  getPositionCovarianceEigenSq(time_to_check, major_axis_sq, minor_axis_sq);

  // if the covariance is very small, the tracker is confident
  constexpr double STRONG_COV_THRESHOLD = 0.28;
  if (major_axis_sq < STRONG_COV_THRESHOLD) {
    return true;
  }

  // if the existence probability is high and the covariance is small enough with respect to its
  // distance to ego and its bev area, the tracker is confident
  // base threshold is 1.6, fallback threshold is 2.6;
  const double adaptive_threshold = computeAdaptiveThreshold(1.6, 2.6, cache, ego_pose);

  if (getTotalExistenceProbability() > 0.50 && major_axis_sq < adaptive_threshold) {
    return true;
  }

  return false;
}

bool Tracker::isExpired(
  const rclcpp::Time & time, const AdaptiveThresholdCache & cache,
  const std::optional<geometry_msgs::msg::Pose> & ego_pose) const
{
  // check the number of no measurements
  const double elapsed_time = getElapsedTimeFromLastUpdate(time);

  // if the last measurement is too old, the tracker is expired
  constexpr double EXPIRED_TIME_THRESHOLD = 1.0;  // [sec]
  if (elapsed_time > EXPIRED_TIME_THRESHOLD) {
    return true;
  }

  // if the tracker is not confident, the tracker is expired
  constexpr double EXPIRED_PROBABILITY_THRESHOLD = 0.015;
  const float existence_probability = getTotalExistenceProbability();
  if (existence_probability < EXPIRED_PROBABILITY_THRESHOLD) {
    return true;
  }

  // if the tracker is a bit old and the existence probability is low, check the covariance size
  constexpr double TIME_TO_CHECK_COV = 0.18;  // [sec]
  constexpr double EXISTENCE_PROBABILITY_TO_CHECK_COV = 0.3;
  if (
    elapsed_time > TIME_TO_CHECK_COV &&
    existence_probability < EXISTENCE_PROBABILITY_TO_CHECK_COV) {
    // if the tracker covariance is too large, the tracker is expired
    double major_axis_sq = 0.0;
    double minor_axis_sq = 0.0;
    getPositionCovarianceEigenSq(time, major_axis_sq, minor_axis_sq);
    // major_cov: base_threshold is 2.8, fallback threshold is 3.8;
    // minor_cov: base_threshold is 2.7, fallback threshold is 3.7;
    const double major_cov_threshold = computeAdaptiveThreshold(2.8, 3.8, cache, ego_pose);
    const double minor_cov_threshold = computeAdaptiveThreshold(2.7, 3.7, cache, ego_pose);
    if (major_axis_sq > major_cov_threshold || minor_axis_sq > minor_cov_threshold) {
      return true;
    }
  }

  return false;
}

float Tracker::getKnownObjectProbability() const
{
  // find unknown probability
  float unknown_probability = 0.0;
  for (const auto & a_class : classification_) {
    if (a_class.label == classes::Label::UNKNOWN) {
      unknown_probability = a_class.probability;
      break;
    }
  }
  // known object probability is reverse of unknown probability
  return 1.0 - unknown_probability;
}

double Tracker::getPositionCovarianceDeterminant() const
{
  using autoware_utils_geometry::xyzrpy_covariance_index::XYZRPY_COV_IDX;
  // Covariance is owned by the motion model; query it at the current state time.
  geometry_msgs::msg::Pose pose;
  geometry_msgs::msg::Twist twist;
  std::array<double, 36> pose_cov{};
  std::array<double, 36> twist_cov{};
  if (!getMotionState(getStateTime(), pose, pose_cov, twist, twist_cov)) {
    return std::numeric_limits<double>::max();
  }

  // The covariance size is defined as the square of the dominant eigenvalue
  // of the 2x2 covariance matrix:
  // | X_X  X_Y |
  // | Y_X  Y_Y |
  const double determinant = pose_cov[XYZRPY_COV_IDX::X_X] * pose_cov[XYZRPY_COV_IDX::Y_Y] -
                             pose_cov[XYZRPY_COV_IDX::X_Y] * pose_cov[XYZRPY_COV_IDX::Y_X];
  // covariance matrix is positive semi-definite
  if (determinant <= 0.0) {
    RCLCPP_WARN(
      rclcpp::get_logger("Tracker"), "Covariance is not positive semi-definite. X_X: %f, Y_Y: %f",
      pose_cov[XYZRPY_COV_IDX::X_X], pose_cov[XYZRPY_COV_IDX::Y_Y]);
    // return a large value to indicate the covariance is not valid
    return std::numeric_limits<double>::max();
  }
  return determinant;
}

bool Tracker::conditionedUpdate(
  const types::DynamicObject & measurement, const types::DynamicObject & prediction,
  const rclcpp::Time & measurement_time, const types::InputChannel & channel_info)
{
  (void)measurement;
  (void)prediction;
  (void)measurement_time;
  (void)channel_info;
  RCLCPP_ERROR(
    rclcpp::get_logger("Tracker"),
    "Tracker::conditionedUpdate: Base class method is NOT expected to be called.");
  return false;
}

}  // namespace autoware::multi_object_tracker
