// Copyright 2026 TIER IV, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "multi_object_tracker_core.hpp"

#include <autoware/agnocast_wrapper/tf2.hpp>

#include <functional>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace autoware::multi_object_tracker
{

MultiObjectTrackerInternalState::MultiObjectTrackerInternalState()
: last_publish_time(0, 0, RCL_ROS_TIME),
  last_updated_time(0, 0, RCL_ROS_TIME),
  last_tracker_time(0, 0, RCL_ROS_TIME)
{
}

void MultiObjectTrackerInternalState::init(
  const MultiObjectTrackerParameters & params, autoware::agnocast_wrapper::Node & node,
  const std::function<void(size_t)> & trigger_function)
{
  auto tf_buffer = std::make_shared<autoware::agnocast_wrapper::Buffer>(node.get_clock());
  odometry = std::make_shared<Odometry>(
    node.get_logger(), node.get_clock(), tf_buffer, params.world_frame_id, params.ego_frame_id,
    params.enable_odometry_uncertainty, params.ego_source);

  // Initialize input manager
  input_manager = std::make_unique<InputManager>(odometry, node.get_logger(), node.get_clock());
  input_manager->init(params.input_channels_config);
  input_manager->setTriggerFunction(trigger_function);

  // Initialize processor
  processor = std::make_unique<TrackerProcessor>(
    params.tracker_configs, params.creation_config, params.association_config,
    params.tracker_overlap_manager_config, params.input_channels_config, node.get_logger(),
    node.get_clock());

  last_publish_time = node.now();
  last_updated_time = node.now();
  last_tracker_time = node.now();
}

namespace
{
std::optional<geometry_msgs::msg::PoseStamped> getEgoPoseAt(
  const rclcpp::Time & time, const MultiObjectTrackerInternalState & state)
{
  if (const auto odometry_info = state.odometry->getOdometryFromTf(time)) {
    geometry_msgs::msg::PoseStamped ps;
    ps.header.stamp = odometry_info->header.stamp;
    ps.pose = odometry_info->pose.pose;
    return ps;
  }
  return std::nullopt;
}
}  // namespace

namespace core
{

//// Parameter processing
void process_parameters(MultiObjectTrackerParameters & params)
{
  // For each (shape, label) in the association config, validate that its designated create
  // tracker also appears in its own match list. Per-tracker profile validity within each
  // match list is already guaranteed by the parser (missing entries throw at startup).
  for (const auto & [shape_label, profile_map] : params.association_config.association_params_map) {
    const auto default_tracker_opt =
      get_map_value_if_exists(params.creation_config.shape_tracker_map, shape_label);
    if (!default_tracker_opt) continue;

    if (!get_map_value_if_exists(profile_map, default_tracker_opt->get())) {
      const auto shape_str = types::toString(shape_label.first);
      const auto label_str = classes::toString(shape_label.second);
      throw std::runtime_error(
        "Inconsistent configuration: create tracker '" + toString(default_tracker_opt->get()) +
        "' for (" + shape_str + ", " + label_str +
        ") is not in the match list. Check tracker_assignment." + shape_str + "." + label_str +
        ".match in the parameter file.");
    }
  }
}

//// Utility functions
bool should_publish(
  const rclcpp::Time & current_time, const MultiObjectTrackerParameters & params,
  MultiObjectTrackerInternalState & state)
{
  if (state.last_updated_time.nanoseconds() == 0) {
    state.last_updated_time = current_time;
  }

  // ensure minimum interval: room for the next process(prediction)
  static constexpr double minimum_publish_interval_ratio = 0.85;
  static constexpr double maximum_publish_interval_ratio = 1.05;

  const double publisher_period = 1.0 / params.publish_rate;
  const double minimum_publish_interval = publisher_period * minimum_publish_interval_ratio;
  const auto elapsed_time = (current_time - state.last_publish_time).seconds();

  if (elapsed_time < minimum_publish_interval) {
    return false;
  }

  // if there was update after publishing, publish new messages
  bool should_publish = state.last_publish_time < state.last_updated_time;

  // if there was no update, publish if the elapsed time is longer than the maximum publish latency
  // in this case, it will perform extrapolate/remove old objects
  const double maximum_publish_interval = publisher_period * maximum_publish_interval_ratio;
  should_publish = should_publish || elapsed_time > maximum_publish_interval;

  return should_publish;
}

autoware_perception_msgs::msg::TrackedObjects get_tracked_objects_(
  const rclcpp::Time & object_time, const MultiObjectTrackerParameters & params,
  const MultiObjectTrackerInternalState & state)
{
  autoware_perception_msgs::msg::TrackedObjects tracked_objects;
  tracked_objects.header.frame_id = params.world_frame_id;
  state.processor->getTrackedObjects(object_time, tracked_objects);

  return tracked_objects;
}

std::optional<autoware_perception_msgs::msg::DetectedObjects> get_merged_objects_(
  const rclcpp::Time & object_time, const MultiObjectTrackerParameters & params,
  const MultiObjectTrackerInternalState & state, const rclcpp::Logger & logger)
{
  if (!params.publish_merged_objects) {
    return std::nullopt;
  }

  const auto & last_tracker_time = state.last_tracker_time;

  const auto tf_base_to_world = state.odometry->getTransform(last_tracker_time);
  if (tf_base_to_world) {
    autoware_perception_msgs::msg::DetectedObjects merged_output_msg;
    state.processor->getMergedObjects(object_time, *tf_base_to_world, merged_output_msg);
    merged_output_msg.header.frame_id = params.ego_frame_id;
    return merged_output_msg;
  }

  RCLCPP_WARN(
    logger, "No odometry information available at the publishing time: %.9f",
    last_tracker_time.seconds());
  return std::nullopt;
}

//// Low-level processing functions
MeasurementProcessingResult process_measurement(
  const size_t channel_index,
  AUTOWARE_MESSAGE_CONST_SHARED_PTR(autoware_perception_msgs::msg::DetectedObjects) msg,
  const rclcpp::Time & current_time, MultiObjectTrackerInternalState & state,
  TrackerDebugger & debugger)
{
  MeasurementProcessingResult result;
  result.has_objects = false;
  result.should_process = false;

  const auto objects = state.input_manager->processMessage(channel_index, msg);
  if (!objects) {
    return result;
  }

  // Update ego pose to the measurement timestamp so association uses a fresh pose
  const rclcpp::Time measurement_time =
    rclcpp::Time(objects->header.stamp, current_time.get_clock_type());
  const auto ego_pose = getEgoPoseAt(measurement_time, state);
  if (!ego_pose) {
    RCLCPP_WARN(
      rclcpp::get_logger("multi_object_tracker"),
      "Failed to get ego pose at measurement timestamp. Proceeding without ego pose.");
  }
  state.processor->updateEgoPose(ego_pose);

  const auto association_result = state.processor->associate(*objects);
  state.input_manager->push(channel_index, *objects, association_result);

  result.has_objects = true;
  result.should_process = (channel_index == state.input_manager->getTargetChannelIdx());

  // Collect debug information - tracker list, existence probabilities, association results
  const types::AssociatedObjects associated_objects{*objects, association_result};
  debugger.collectObjectInfo(
    measurement_time, state.processor->getListTracker(), associated_objects);

  return result;
}

void process_objects_(
  const types::ObjectsWithAssociation & objects_with_associations,
  const rclcpp::Time & current_time, MultiObjectTrackerInternalState & state,
  const rclcpp::Logger & logger)
{
  // Get the time of the measurement
  const rclcpp::Time measurement_time =
    objects_with_associations.getTimestamp(current_time.get_clock_type());

  // Get ego pose
  const auto ego_pose_stamped = getEgoPoseAt(measurement_time, state);
  if (!ego_pose_stamped) {
    RCLCPP_WARN(
      logger, "No odometry information available at the measurement time: %.9f",
      measurement_time.seconds());
  }
  state.processor->updateEgoPose(ego_pose_stamped);

  /// 1. Update ego pose and predict trackers to measurement time
  state.processor->predictTrackers(measurement_time);

  /// 2. Object association
  const types::AssociatedObjects associated_objects{
    objects_with_associations.objects, objects_with_associations.association};

  /// 3. Tracker update
  state.processor->update(associated_objects);

  /// 4. Tracker pruning
  state.processor->prune(measurement_time);

  /// 5. Spawn new tracker
  state.processor->spawn(associated_objects);
}

//// High-level orchestration functions
ObjectProcessingResult process_objects_batch(
  const rclcpp::Time & current_time, const MultiObjectTrackerParameters & params,
  MultiObjectTrackerInternalState & state, TrackerDebugger & debugger,
  const rclcpp::Logger & logger)
{
  ObjectProcessingResult result;
  result.should_publish = false;

  // get objects from the input manager and run process
  types::ObjectsWithAssociationList objects_with_associations;
  const bool is_objects_ready =
    state.input_manager->getObjects(current_time, objects_with_associations);
  if (!is_objects_ready) {
    return result;
  }

  // process start - start measurement time before processing
  debugger.startMeasurementTime(current_time, objects_with_associations.back().getTimestamp());

  // run process for each DynamicObject
  for (const auto & objects_data : objects_with_associations) {
    process_objects_(objects_data, current_time, state, logger);
  }

  // Update last_updated_time and last_tracker_time
  state.last_updated_time = current_time;
  state.last_tracker_time = objects_with_associations.back().getTimestamp();

  // process end - end measurement time after processing
  debugger.endMeasurementTime(current_time);

  // Publish immediately when the timer is disabled; otherwise the periodic timer drives publishing.
  // This is independent of delay_compensation, which only selects the export reference time.
  result.should_publish = !params.publish_on_timer;

  return result;
}

PublishingData prepare_publishing_data(
  const rclcpp::Time & current_time, const MultiObjectTrackerParameters & params,
  MultiObjectTrackerInternalState & state, [[maybe_unused]] const rclcpp::Logger & logger)
{
  PublishingData result;

  const auto & last_tracker_time = state.last_tracker_time;

  // Calculate object_time based on the export-time reference
  switch (params.delay_compensation) {
    case DelayReference::NONE:
      result.object_time = last_tracker_time;
      break;
    case DelayReference::PUBLISH_DELAY: {
      // Advance the detection stamp by the update->publish delay (wall-clock elapsed since the last
      // tracker update). Compensates the publish-side latency without over-extrapolating by the
      // sensor->tracker pipeline delay (as FULL would).
      const auto elapsed = current_time - state.last_updated_time;
      result.object_time =
        last_tracker_time + (elapsed.seconds() > 0.0 ? elapsed : rclcpp::Duration(0, 0));
      break;
    }
    case DelayReference::ODOMETRY:
      result.object_time = state.odometry->getLatestEgoPoseTime().value_or(current_time);
      // If no odometry is available, fall back to the current time.
      break;
    case DelayReference::FULL:
      result.object_time = current_time;
      break;
  }

  /// Tracker pruning
  state.processor->prune(last_tracker_time);

  // Get tracked objects
  result.tracked_objects = get_tracked_objects_(result.object_time, params, state);
  result.tracked_objects_size = result.tracked_objects.objects.size();

  // Update last_publish_time
  state.last_publish_time = current_time;

  return result;
}

OptionalPublishingData prepare_optional_publishing_data(
  const rclcpp::Time & object_time, const MultiObjectTrackerParameters & params,
  const MultiObjectTrackerInternalState & state, const TrackerDebugger & debugger,
  const rclcpp::Logger & logger)
{
  OptionalPublishingData result;

  // Get merged objects
  if (params.publish_merged_objects) {
    result.merged_objects = get_merged_objects_(object_time, params, state, logger);
  }

  // Calculate min_extrapolation_time
  const double dt = (object_time - state.last_tracker_time).seconds();
  result.min_extrapolation_time = dt > 0.0 ? dt : 0.0;

  // Prepare tentative objects
  if (debugger.shouldPublishTentativeObjects()) {
    autoware_perception_msgs::msg::TrackedObjects tentative_objects;
    tentative_objects.header.frame_id = params.world_frame_id;
    state.processor->getTentativeObjects(object_time, tentative_objects);
    result.tentative_objects = std::move(tentative_objects);
  }

  return result;
}

}  // namespace core
}  // namespace autoware::multi_object_tracker
