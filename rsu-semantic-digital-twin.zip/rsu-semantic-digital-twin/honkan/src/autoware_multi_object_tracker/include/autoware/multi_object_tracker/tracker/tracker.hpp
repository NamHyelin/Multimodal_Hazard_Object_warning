// Copyright 2020 TIER IV, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef AUTOWARE__MULTI_OBJECT_TRACKER__TRACKER__TRACKER_HPP_
#define AUTOWARE__MULTI_OBJECT_TRACKER__TRACKER__TRACKER_HPP_

#include "trackers/multiple_vehicle_tracker.hpp"
#include "trackers/pedestrian_and_bicycle_tracker.hpp"
#include "trackers/pedestrian_tracker.hpp"
#include "trackers/polygon_tracker.hpp"
#include "trackers/tracker_base.hpp"
#include "trackers/vehicle_tracker.hpp"

#endif  // AUTOWARE__MULTI_OBJECT_TRACKER__TRACKER__TRACKER_HPP_
