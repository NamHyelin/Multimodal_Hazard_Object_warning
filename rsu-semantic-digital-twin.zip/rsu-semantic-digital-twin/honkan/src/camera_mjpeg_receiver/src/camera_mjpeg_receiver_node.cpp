#include <fcntl.h>
#include <signal.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

#include <array>
#include <atomic>
#include <chrono>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include <geometry_msgs/msg/transform_stamped.hpp>
#include <opencv2/imgcodecs.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/image_encodings.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <tf2_ros/static_transform_broadcaster.h>
#include <yaml-cpp/yaml.h>

#include "jpeg_stream_server.hpp"

extern char ** environ;

namespace
{
constexpr std::size_t kMaxJpegBytes = 2'000'000U;

struct CameraConfig
{
  std::string name;
  std::string frame_id;
  std::string image_topic;
  std::string info_topic;
  std::string sdp;
  std::string calibration;
};

sensor_msgs::msg::CameraInfo load_camera_info(const std::string & path)
{
  const YAML::Node data = YAML::LoadFile(path);
  sensor_msgs::msg::CameraInfo info;
  info.width = data["image_width"].as<std::uint32_t>();
  info.height = data["image_height"].as<std::uint32_t>();
  info.distortion_model = data["distortion_model"].as<std::string>("plumb_bob");
  info.d = data["distortion_coefficients"]["data"].as<std::vector<double>>();
  info.k = data["camera_matrix"]["data"].as<std::array<double, 9>>();
  info.r = data["rectification_matrix"]["data"].as<std::array<double, 9>>();
  info.p = data["projection_matrix"]["data"].as<std::array<double, 12>>();
  return info;
}

class CameraWorker
{
public:
  CameraWorker(rclcpp::Node & node, CameraConfig config)
  : node_(node),
    config_(std::move(config)),
    jpeg_stream_(config_.name),
    image_pub_(node_.create_publisher<sensor_msgs::msg::Image>(
        config_.image_topic, rclcpp::SensorDataQoS())),
    info_pub_(node_.create_publisher<sensor_msgs::msg::CameraInfo>(
        config_.info_topic, rclcpp::SensorDataQoS())),
    info_template_(load_camera_info(config_.calibration)),
    last_report_(std::chrono::steady_clock::now())
  {
  }

  ~CameraWorker()
  {
    stop();
  }

  CameraWorker(const CameraWorker &) = delete;
  CameraWorker & operator=(const CameraWorker &) = delete;

  void start()
  {
    thread_ = std::thread([this]() {run();});
  }

  void stop()
  {
    if (stopping_.exchange(true)) {
      return;
    }
    const pid_t pid = child_pid_.load();
    if (pid > 0) {
      static_cast<void>(::kill(pid, SIGTERM));
    }
    const int fd = read_fd_.exchange(-1);
    if (fd >= 0) {
      static_cast<void>(::close(fd));
    }
    if (thread_.joinable()) {
      thread_.join();
    }
    jpeg_stream_.stop();
  }

private:
  int spawn_ffmpeg()
  {
    int pipe_fds[2];
    if (::pipe2(pipe_fds, O_CLOEXEC) != 0) {
      throw std::runtime_error("pipe2 failed: " + std::string(std::strerror(errno)));
    }

    const std::string log_path =
      "/autoware_runtime/logs/camera_ffmpeg_" + config_.name + ".log";
    const int log_fd = ::open(log_path.c_str(), O_CREAT | O_WRONLY | O_APPEND | O_CLOEXEC, 0644);
    if (log_fd < 0) {
      ::close(pipe_fds[0]);
      ::close(pipe_fds[1]);
      throw std::runtime_error("open log failed: " + std::string(std::strerror(errno)));
    }

    std::vector<std::string> arguments = {
      "ffmpeg", "-hide_banner", "-loglevel", "error",
      "-protocol_whitelist", "file,udp,rtp",
      "-max_delay", "120000", "-i", config_.sdp,
      "-an", "-sn", "-dn", "-c:v", "copy", "-f", "image2pipe", "pipe:1"
    };
    std::vector<char *> argv;
    argv.reserve(arguments.size() + 1U);
    for (auto & argument : arguments) {
      argv.push_back(argument.data());
    }
    argv.push_back(nullptr);

    posix_spawn_file_actions_t actions;
    ::posix_spawn_file_actions_init(&actions);
    ::posix_spawn_file_actions_adddup2(&actions, pipe_fds[1], STDOUT_FILENO);
    ::posix_spawn_file_actions_adddup2(&actions, log_fd, STDERR_FILENO);
    ::posix_spawn_file_actions_addclose(&actions, pipe_fds[0]);
    ::posix_spawn_file_actions_addclose(&actions, pipe_fds[1]);
    ::posix_spawn_file_actions_addclose(&actions, log_fd);

    pid_t pid = -1;
    const int result = ::posix_spawnp(
      &pid, "ffmpeg", &actions, nullptr, argv.data(), environ);
    ::posix_spawn_file_actions_destroy(&actions);
    ::close(pipe_fds[1]);
    ::close(log_fd);

    if (result != 0) {
      ::close(pipe_fds[0]);
      throw std::runtime_error("posix_spawnp failed: " + std::string(std::strerror(result)));
    }

    child_pid_.store(pid);
    read_fd_.store(pipe_fds[0]);
    RCLCPP_INFO(
      node_.get_logger(), "%s receiver started: %s -> %s",
      config_.name.c_str(), config_.sdp.c_str(), config_.image_topic.c_str());
    return pipe_fds[0];
  }

  void decode_and_publish(const std::vector<std::uint8_t> & jpeg)
  {
    const cv::Mat encoded(
      1, static_cast<int>(jpeg.size()), CV_8UC1,
      const_cast<std::uint8_t *>(jpeg.data()));
    const cv::Mat decoded = cv::imdecode(encoded, cv::IMREAD_COLOR);
    if (decoded.empty()) {
      RCLCPP_WARN(node_.get_logger(), "%s JPEG decode failed", config_.name.c_str());
      return;
    }

    const auto stamp = node_.now();
    sensor_msgs::msg::Image image;
    image.header.stamp = stamp;
    image.header.frame_id = config_.frame_id;
    image.height = static_cast<std::uint32_t>(decoded.rows);
    image.width = static_cast<std::uint32_t>(decoded.cols);
    image.encoding = sensor_msgs::image_encodings::BGR8;
    image.is_bigendian = false;
    image.step = static_cast<sensor_msgs::msg::Image::_step_type>(
      decoded.cols * decoded.elemSize());
    const std::size_t image_bytes = static_cast<std::size_t>(image.step) * image.height;
    image.data.resize(image_bytes);
    if (decoded.isContinuous()) {
      std::memcpy(image.data.data(), decoded.data, image_bytes);
    } else {
      for (int row = 0; row < decoded.rows; ++row) {
        std::memcpy(
          image.data.data() + static_cast<std::size_t>(row) * image.step,
          decoded.ptr(row), image.step);
      }
    }
    image_pub_->publish(image);

    auto info = info_template_;
    info.header.stamp = stamp;
    info.header.frame_id = config_.frame_id;
    info_pub_->publish(info);

    // Reuse the original JPEG with exactly the same stamp as Image/CameraInfo.
    // The viewer transport has its own bounded sender and cannot block this worker.
    jpeg_stream_.publish(jpeg, image.header.stamp.sec, image.header.stamp.nanosec);

    ++frames_;
    const auto now = std::chrono::steady_clock::now();
    const double elapsed = std::chrono::duration<double>(now - last_report_).count();
    if (elapsed >= 10.0) {
      RCLCPP_INFO(
        node_.get_logger(), "%s published %.1f fps",
        config_.name.c_str(), static_cast<double>(frames_) / elapsed);
      frames_ = 0U;
      last_report_ = now;
    }
  }

  int run_once()
  {
    const int fd = spawn_ffmpeg();
    std::vector<std::uint8_t> jpeg;
    jpeg.reserve(128U * 1024U);
    bool in_frame = false;
    bool previous_ff = false;
    std::uint8_t buffer[64U * 1024U];

    while (rclcpp::ok() && !stopping_.load()) {
      const ssize_t bytes_read = ::read(fd, buffer, sizeof(buffer));
      if (bytes_read == 0) {
        break;
      }
      if (bytes_read < 0) {
        if (errno == EINTR) {
          continue;
        }
        if (!stopping_.load()) {
          RCLCPP_WARN(
            node_.get_logger(), "%s read failed: %s",
            config_.name.c_str(), std::strerror(errno));
        }
        break;
      }

      for (ssize_t index = 0; index < bytes_read; ++index) {
        const std::uint8_t value = buffer[index];
        if (!in_frame) {
          if (previous_ff && value == 0xD8U) {
            jpeg.clear();
            jpeg.push_back(0xFFU);
            jpeg.push_back(0xD8U);
            in_frame = true;
            previous_ff = false;
          } else {
            previous_ff = value == 0xFFU;
          }
          continue;
        }

        jpeg.push_back(value);
        if (previous_ff && value == 0xD9U) {
          decode_and_publish(jpeg);
          jpeg = std::vector<std::uint8_t>();
          jpeg.reserve(128U * 1024U);
          in_frame = false;
          previous_ff = false;
          continue;
        }
        previous_ff = value == 0xFFU;
        if (jpeg.size() > kMaxJpegBytes) {
          RCLCPP_WARN(node_.get_logger(), "%s oversized JPEG discarded", config_.name.c_str());
          jpeg.clear();
          in_frame = false;
          previous_ff = false;
        }
      }
    }

    const int owned_fd = read_fd_.exchange(-1);
    if (owned_fd >= 0) {
      ::close(owned_fd);
    }

    const pid_t pid = child_pid_.exchange(-1);
    if (pid <= 0) {
      return -1;
    }
    if (stopping_.load()) {
      static_cast<void>(::kill(pid, SIGTERM));
    }

    int status = 0;
    while (::waitpid(pid, &status, 0) < 0 && errno == EINTR) {
    }
    if (WIFEXITED(status)) {
      return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
      return 128 + WTERMSIG(status);
    }
    return -1;
  }

  void run()
  {
    while (rclcpp::ok() && !stopping_.load()) {
      int return_code = -1;
      try {
        return_code = run_once();
      } catch (const std::exception & error) {
        RCLCPP_ERROR(
          node_.get_logger(), "%s receiver error: %s",
          config_.name.c_str(), error.what());
      }
      if (stopping_.load() || !rclcpp::ok()) {
        break;
      }
      RCLCPP_WARN(
        node_.get_logger(), "%s ffmpeg stopped, return_code=%d; restarting",
        config_.name.c_str(), return_code);
      std::this_thread::sleep_for(std::chrono::seconds(1));
    }
  }

  rclcpp::Node & node_;
  CameraConfig config_;
  JpegStreamServer jpeg_stream_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr image_pub_;
  rclcpp::Publisher<sensor_msgs::msg::CameraInfo>::SharedPtr info_pub_;
  sensor_msgs::msg::CameraInfo info_template_;
  std::thread thread_;
  std::atomic<bool> stopping_{false};
  std::atomic<pid_t> child_pid_{-1};
  std::atomic<int> read_fd_{-1};
  std::uint64_t frames_{0U};
  std::chrono::steady_clock::time_point last_report_;
};

class CameraMjpegReceiverNode : public rclcpp::Node
{
public:
  CameraMjpegReceiverNode()
  : Node("camera_mjpeg_receiver")
  {
    static_broadcaster_ = std::make_shared<tf2_ros::StaticTransformBroadcaster>(this);
    const std::vector<std::string> extrinsic_paths = {
      "/autoware_runtime/calibration/sensor_kit/gate_camera_extrinsic.yaml",
      "/autoware_runtime/calibration/sensor_kit/intersection_camera_extrinsic.yaml"
    };
    std::vector<geometry_msgs::msg::TransformStamped> static_transforms;
    static_transforms.reserve(extrinsic_paths.size());
    for (const auto & extrinsic_path : extrinsic_paths) {
      const YAML::Node extrinsic = YAML::LoadFile(extrinsic_path);
      geometry_msgs::msg::TransformStamped transform;
      transform.header.stamp = now();
      transform.header.frame_id = extrinsic["parent_frame"].as<std::string>();
      transform.child_frame_id = extrinsic["child_frame"].as<std::string>();
      transform.transform.translation.x = extrinsic["translation"]["x"].as<double>();
      transform.transform.translation.y = extrinsic["translation"]["y"].as<double>();
      transform.transform.translation.z = extrinsic["translation"]["z"].as<double>();
      transform.transform.rotation.x = extrinsic["rotation"]["x"].as<double>();
      transform.transform.rotation.y = extrinsic["rotation"]["y"].as<double>();
      transform.transform.rotation.z = extrinsic["rotation"]["z"].as<double>();
      transform.transform.rotation.w = extrinsic["rotation"]["w"].as<double>();
      RCLCPP_INFO(
        get_logger(), "loaded static TF %s -> %s from %s",
        transform.header.frame_id.c_str(), transform.child_frame_id.c_str(),
        extrinsic_path.c_str());
      static_transforms.push_back(std::move(transform));
    }
    static_broadcaster_->sendTransform(static_transforms);

    const std::vector<CameraConfig> cameras = {
      {
        "gate", "gate_camera",
        "/rsu1/gate/image_raw", "/rsu1/gate/camera_info",
        "/autoware_runtime/config/topics/gate_camera.sdp",
        "/autoware_runtime/calibration/sensor_kit/gate_camera.yaml"
      },
      {
        "intersection", "intersection_camera",
        "/rsu1/intersection/image_raw", "/rsu1/intersection/camera_info",
        "/autoware_runtime/config/topics/intersection_camera.sdp",
        "/autoware_runtime/calibration/sensor_kit/intersection_camera.yaml"
      }
    };

    workers_.reserve(cameras.size());
    for (const auto & camera : cameras) {
      workers_.push_back(std::make_unique<CameraWorker>(*this, camera));
    }
    for (auto & worker : workers_) {
      worker->start();
    }
  }

  ~CameraMjpegReceiverNode() override
  {
    for (auto & worker : workers_) {
      worker->stop();
    }
  }

private:
  std::shared_ptr<tf2_ros::StaticTransformBroadcaster> static_broadcaster_;
  std::vector<std::unique_ptr<CameraWorker>> workers_;
};
}  // namespace

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<CameraMjpegReceiverNode>();
  rclcpp::spin(node);
  node.reset();
  if (rclcpp::ok()) {
    rclcpp::shutdown();
  }
  return 0;
}
