#pragma once

#include <arpa/inet.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

// One local viewer per camera. A slow/disconnected viewer never blocks ROS
// publication: a separate thread sends only the latest complete JPEG snapshot.
// Linux abstract sockets need no socket-file cleanup and expose no TCP port.
// Wire: "JPG1", uint32 payload bytes, uint32 ROS sec, uint32 ROS nsec (network order).
class JpegStreamServer
{
public:
  explicit JpegStreamServer(const std::string & camera)
  {
    const std::string name = "perception_" + camera + "_jpeg_v1";
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    if (name.size() + 1 >= sizeof(address.sun_path)) {
      throw std::runtime_error("JPEG socket name too long");
    }
    std::memcpy(address.sun_path + 1, name.data(), name.size());
    listener_ = ::socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (listener_ < 0) {throw std::runtime_error("JPEG socket creation failed");}
    const auto length = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + 1 + name.size());
    if (::bind(listener_, reinterpret_cast<sockaddr *>(&address), length) < 0 ||
      ::listen(listener_, 1) < 0)
    {
      ::close(listener_);
      throw std::runtime_error("JPEG socket bind/listen failed: " + name);
    }
    thread_ = std::thread([this]() {run();});
  }

  ~JpegStreamServer() {stop();}
  JpegStreamServer(const JpegStreamServer &) = delete;
  JpegStreamServer & operator=(const JpegStreamServer &) = delete;

  void stop()
  {
    if (stopping_.exchange(true)) {return;}
    ready_.notify_all();
    if (thread_.joinable()) {thread_.join();}
    ::close(listener_);
  }

  void publish(const std::vector<std::uint8_t> & jpeg, std::uint32_t sec, std::uint32_t nsec)
  {
    auto frame = std::make_shared<std::vector<std::uint8_t>>();
    frame->reserve(16 + jpeg.size());
    frame->insert(frame->end(), {'J', 'P', 'G', '1'});
    const std::uint32_t header[] = {
      htonl(static_cast<std::uint32_t>(jpeg.size())), htonl(sec), htonl(nsec)};
    const auto * bytes = reinterpret_cast<const std::uint8_t *>(header);
    frame->insert(frame->end(), bytes, bytes + sizeof(header));
    frame->insert(frame->end(), jpeg.begin(), jpeg.end());
    {
      std::lock_guard<std::mutex> lock(mutex_);
      latest_ = std::move(frame);
      ++sequence_;
    }
    ready_.notify_one();
  }

private:
  void run()
  {
    while (!stopping_) {
      pollfd descriptor{listener_, POLLIN, 0};
      if (::poll(&descriptor, 1, 100) <= 0) {continue;}
      const int client = ::accept4(listener_, nullptr, nullptr, SOCK_CLOEXEC);
      if (client < 0) {continue;}
      const timeval timeout{0, 200000};
      ::setsockopt(client, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
      std::uint64_t sent = 0;
      bool connected = true;
      while (!stopping_ && connected) {
        std::shared_ptr<const std::vector<std::uint8_t>> frame;
        {
          std::unique_lock<std::mutex> lock(mutex_);
          ready_.wait_for(lock, std::chrono::milliseconds(100),
            [this, sent]() {return stopping_ || sequence_ != sent;});
          if (stopping_) {break;}
          if (!latest_ || sequence_ == sent) {continue;}
          frame = latest_;
          sent = sequence_;
        }
        std::size_t offset = 0;
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(500);
        while (offset < frame->size() && !stopping_) {
          const auto n = ::send(client, frame->data() + offset, frame->size() - offset, MSG_NOSIGNAL);
          if (n <= 0 || std::chrono::steady_clock::now() > deadline) {
            connected = false;
            break;
          }
          offset += static_cast<std::size_t>(n);
        }
      }
      ::close(client);
    }
  }

  int listener_{-1};
  std::atomic<bool> stopping_{false};
  std::mutex mutex_;
  std::condition_variable ready_;
  std::shared_ptr<const std::vector<std::uint8_t>> latest_;
  std::uint64_t sequence_{0};
  std::thread thread_;
};
