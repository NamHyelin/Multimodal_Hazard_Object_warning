#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <deque>
#include <memory>
#include <stdexcept>
#include <string>

#include <geometry_msgs/msg/transform_stamped.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/msg/point_field.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>

using Cloud = sensor_msgs::msg::PointCloud2;

class StrictFrontFusionNode : public rclcpp::Node
{
public:
  StrictFrontFusionNode()
  : Node("strict_front_fusion"), tf_buffer_(get_clock()), tf_listener_(tf_buffer_)
  {
    tolerance_ = declare_parameter<double>("sync_tolerance_sec", 0.035);
    output_frame_ = declare_parameter<std::string>("output_frame", "lidar_fusion");
    const auto qos = rclcpp::SensorDataQoS().keep_last(10);
    publisher_ = create_publisher<Cloud>("/sensing/lidar/concatenated/pointcloud", qos);
    centerpoint_hz_ = declare_parameter<double>("centerpoint_max_hz", 0.0);
    centerpoint_pub_ = create_publisher<Cloud>(
      "/sensing/lidar/centerpoint/pointcloud", rclcpp::SensorDataQoS().keep_last(1));
    if (centerpoint_hz_ > 0) {
      centerpoint_timer_ = create_wall_timer(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
          std::chrono::duration<double>(1.0 / centerpoint_hz_)),
        [this]() {publish_latest();});
    }
    sub1_ = create_subscription<Cloud>(
      "/rsu1/sensing/lidar/pointcloud", qos,
      [this](Cloud::ConstSharedPtr m) { ++received1_; q1_.push_back(m); trim(q1_, overflow1_); match(); });
    sub4_ = create_subscription<Cloud>(
      "/rsu4/sensing/lidar/pointcloud", qos,
      [this](Cloud::ConstSharedPtr m) { ++received4_; q4_.push_back(m); trim(q4_, overflow4_); match(); });
    report_time_ = std::chrono::steady_clock::now();
    report_timer_ = create_wall_timer(std::chrono::seconds(5), [this]() {report_transport();});
    RCLCPP_INFO(get_logger(), "Strict dual-LiDAR gate: tolerance %.1f ms, output frame %s",
      tolerance_ * 1000.0, output_frame_.c_str());
  }

private:
  static double stamp(const Cloud & m)
  {
    return static_cast<double>(m.header.stamp.sec) + 1e-9 * m.header.stamp.nanosec;
  }

  static void trim(std::deque<Cloud::ConstSharedPtr> & q, std::size_t & overflow)
  {
    while (q.size() > 10) {q.pop_front(); ++overflow;}
  }

  void report_transport()
  {
    const auto now = std::chrono::steady_clock::now();
    const double seconds = std::chrono::duration<double>(now - report_time_).count();
    RCLCPP_INFO(get_logger(),
      "[TRANSPORT] input_rsu1=%.2f Hz input_rsu4=%.2f Hz output=%.2f Hz "
      "centerpoint_input=%.2f Hz unpaired_rsu1=%zu unpaired_rsu4=%zu overflow_rsu1=%zu overflow_rsu4=%zu",
      (received1_ - last_received1_) / seconds, (received4_ - last_received4_) / seconds,
      (paired_ - last_paired_) / seconds, (centerpoint_sent_ - last_centerpoint_sent_) / seconds,
      dropped1_, dropped4_, overflow1_, overflow4_);
    last_received1_ = received1_; last_received4_ = received4_; last_paired_ = paired_;
    last_centerpoint_sent_ = centerpoint_sent_;
    report_time_ = now;
  }

  void publish_latest()
  {
    // Keep one current cloud, not a queue of clouds the detector cannot finish.
    // Never republish a stale frame if either LiDAR stops producing pairs.
    if (!latest_ || delivered_sequence_ == paired_) {return;}
    centerpoint_pub_->publish(*latest_);
    delivered_sequence_ = paired_;
    ++centerpoint_sent_;
  }

  void match()
  {
    while (!q1_.empty() && !q4_.empty()) {
      const double dt = stamp(*q4_.front()) - stamp(*q1_.front());
      if (std::abs(dt) <= tolerance_) {
        const auto a = q1_.front(); const auto b = q4_.front();
        q1_.pop_front(); q4_.pop_front();
        fuse(*a, *b, dt);
      } else if (dt > 0.0) {
        q1_.pop_front(); ++dropped1_;
      } else {
        q4_.pop_front(); ++dropped4_;
      }
    }
  }

  static const sensor_msgs::msg::PointField & get_field(const Cloud & m, const char * name)
  {
    const auto it = std::find_if(m.fields.begin(), m.fields.end(),
      [name](const auto & f) { return f.name == name; });
    if (it == m.fields.end()) throw std::runtime_error(std::string("missing field ") + name);
    return *it;
  }

  static std::array<double, 9> rotation(const geometry_msgs::msg::Quaternion & q)
  {
    const double x=q.x, y=q.y, z=q.z, w=q.w;
    return {1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w),
            2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w),
            2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)};
  }

  static void define_fields(Cloud & out)
  {
    out.fields.resize(6);
    const auto set = [&out](std::size_t n,const char * name,std::uint32_t off,std::uint8_t type) {
      out.fields[n].name=name; out.fields[n].offset=off; out.fields[n].datatype=type; out.fields[n].count=1;
    };
    set(0,"x",0,sensor_msgs::msg::PointField::FLOAT32);
    set(1,"y",4,sensor_msgs::msg::PointField::FLOAT32);
    set(2,"z",8,sensor_msgs::msg::PointField::FLOAT32);
    set(3,"intensity",12,sensor_msgs::msg::PointField::UINT8);
    set(4,"return_type",13,sensor_msgs::msg::PointField::UINT8);
    set(5,"channel",14,sensor_msgs::msg::PointField::UINT16);
  }

  void append_transformed(const Cloud & in, const geometry_msgs::msg::TransformStamped & tf,
    Cloud & out, std::size_t & output_index)
  {
    const auto & fx=get_field(in,"x"); const auto & fy=get_field(in,"y");
    const auto & fz=get_field(in,"z"); const auto & fi=get_field(in,"intensity");
    const auto r=rotation(tf.transform.rotation); const auto & t=tf.transform.translation;
    for (std::uint32_t row=0; row<in.height; ++row) for (std::uint32_t col=0; col<in.width; ++col) {
      const auto * src=in.data.data()+static_cast<std::size_t>(row)*in.row_step+static_cast<std::size_t>(col)*in.point_step;
      float x,y,z,intensity; std::memcpy(&x,src+fx.offset,4); std::memcpy(&y,src+fy.offset,4);
      std::memcpy(&z,src+fz.offset,4); std::memcpy(&intensity,src+fi.offset,4);
      auto * dst=out.data.data()+output_index++*16;
      const float ox=static_cast<float>(r[0]*x+r[1]*y+r[2]*z+t.x);
      const float oy=static_cast<float>(r[3]*x+r[4]*y+r[5]*z+t.y);
      const float oz=static_cast<float>(r[6]*x+r[7]*y+r[8]*z+t.z);
      std::memcpy(dst,&ox,4); std::memcpy(dst+4,&oy,4); std::memcpy(dst+8,&oz,4);
      dst[12]=static_cast<std::uint8_t>(std::clamp(std::lround(intensity),0L,255L));
      dst[13]=1U; const std::uint16_t channel=0U; std::memcpy(dst+14,&channel,2);
    }
  }

  void fuse(const Cloud & a, const Cloud & b, double dt)
  {
    try {
      const auto ta=tf_buffer_.lookupTransform(output_frame_,a.header.frame_id,tf2::TimePointZero);
      const auto tb=tf_buffer_.lookupTransform(output_frame_,b.header.frame_id,tf2::TimePointZero);
      Cloud out; out.header.frame_id=output_frame_;
      out.header.stamp = stamp(a) >= stamp(b) ? a.header.stamp : b.header.stamp;
      out.height=1; out.width=a.width*a.height+b.width*b.height; out.point_step=16;
      out.row_step=out.width*out.point_step; out.is_bigendian=false; out.is_dense=a.is_dense&&b.is_dense;
      define_fields(out); out.data.resize(out.row_step); std::size_t index=0;
      append_transformed(a,ta,out,index); append_transformed(b,tb,out,index);
      ++paired_;
      publisher_->publish(out);
      latest_ = std::make_shared<Cloud>(std::move(out));
      if (centerpoint_hz_ <= 0) {publish_latest();}
      RCLCPP_INFO_THROTTLE(get_logger(),*get_clock(),5000,
        "paired=%zu drop_rsu1=%zu drop_rsu4=%zu last_delta=%.2f ms",paired_,dropped1_,dropped4_,dt*1000.0);
    } catch (const std::exception & e) {
      RCLCPP_WARN_THROTTLE(get_logger(),*get_clock(),5000,"Fusion skipped: %s",e.what());
    }
  }

  double tolerance_; std::string output_frame_;
  tf2_ros::Buffer tf_buffer_; tf2_ros::TransformListener tf_listener_;
  rclcpp::Publisher<Cloud>::SharedPtr publisher_;
  rclcpp::Publisher<Cloud>::SharedPtr centerpoint_pub_;
  Cloud::SharedPtr latest_;
  rclcpp::TimerBase::SharedPtr centerpoint_timer_;
  double centerpoint_hz_{0};
  std::size_t delivered_sequence_{0}, centerpoint_sent_{0}, last_centerpoint_sent_{0};
  rclcpp::Subscription<Cloud>::SharedPtr sub1_,sub4_;
  rclcpp::TimerBase::SharedPtr report_timer_;
  std::chrono::steady_clock::time_point report_time_;
  std::size_t received1_{0}, received4_{0}, overflow1_{0}, overflow4_{0};
  std::size_t last_received1_{0}, last_received4_{0}, last_paired_{0};
  std::deque<Cloud::ConstSharedPtr> q1_,q4_;
  std::size_t paired_{0},dropped1_{0},dropped4_{0};
};

int main(int argc,char ** argv)
{
  rclcpp::init(argc,argv); rclcpp::spin(std::make_shared<StrictFrontFusionNode>());
  rclcpp::shutdown(); return 0;
}
