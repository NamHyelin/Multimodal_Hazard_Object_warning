#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/msg/point_field.hpp>

class XyziToXyzircNode : public rclcpp::Node
{
public:
  XyziToXyzircNode() : Node("xyzi_to_xyzirc_adapter")
  {
    const auto inputs = declare_parameter<std::vector<std::string>>(
      "input_topics", {"/rsu1/sensing/lidar/pointcloud", "/rsu4/sensing/lidar/pointcloud"});
    const auto outputs = declare_parameter<std::vector<std::string>>(
      "output_topics", {"/fusion/rsu1/pointcloud_xyzirc", "/fusion/rsu4/pointcloud_xyzirc"});
    if (inputs.size() != outputs.size() || inputs.empty()) {
      throw std::runtime_error("input_topics and output_topics must have the same non-zero size");
    }

    auto qos = rclcpp::SensorDataQoS().keep_last(10);
    for (std::size_t i = 0; i < inputs.size(); ++i) {
      publishers_.push_back(create_publisher<sensor_msgs::msg::PointCloud2>(outputs[i], qos));
      subscriptions_.push_back(create_subscription<sensor_msgs::msg::PointCloud2>(
        inputs[i], qos,
        [this, i](sensor_msgs::msg::PointCloud2::ConstSharedPtr msg) { convert_and_publish(*msg, i); }));
      RCLCPP_INFO(get_logger(), "%s -> %s", inputs[i].c_str(), outputs[i].c_str());
    }
  }

private:
  static const sensor_msgs::msg::PointField & field(
    const sensor_msgs::msg::PointCloud2 & msg, const std::string & name)
  {
    const auto it = std::find_if(
      msg.fields.begin(), msg.fields.end(), [&name](const auto & f) { return f.name == name; });
    if (it == msg.fields.end()) throw std::runtime_error("missing field: " + name);
    return *it;
  }

  void convert_and_publish(const sensor_msgs::msg::PointCloud2 & in, std::size_t index)
  {
    try {
      if (in.is_bigendian) throw std::runtime_error("big-endian pointcloud is not supported");
      const auto & fx = field(in, "x");
      const auto & fy = field(in, "y");
      const auto & fz = field(in, "z");
      const auto & fi = field(in, "intensity");
      if (fx.datatype != sensor_msgs::msg::PointField::FLOAT32 ||
          fy.datatype != sensor_msgs::msg::PointField::FLOAT32 ||
          fz.datatype != sensor_msgs::msg::PointField::FLOAT32 ||
          fi.datatype != sensor_msgs::msg::PointField::FLOAT32) {
        throw std::runtime_error("expected FLOAT32 x/y/z/intensity fields");
      }

      sensor_msgs::msg::PointCloud2 out;
      out.header = in.header;
      out.height = in.height;
      out.width = in.width;
      out.is_bigendian = false;
      out.is_dense = in.is_dense;
      out.point_step = 16;
      out.row_step = out.width * out.point_step;
      out.fields.resize(6);
      const auto set_field = [&out](std::size_t n, const char * name, std::uint32_t offset, std::uint8_t type) {
        out.fields[n].name = name; out.fields[n].offset = offset;
        out.fields[n].datatype = type; out.fields[n].count = 1;
      };
      set_field(0, "x", 0, sensor_msgs::msg::PointField::FLOAT32);
      set_field(1, "y", 4, sensor_msgs::msg::PointField::FLOAT32);
      set_field(2, "z", 8, sensor_msgs::msg::PointField::FLOAT32);
      set_field(3, "intensity", 12, sensor_msgs::msg::PointField::UINT8);
      set_field(4, "return_type", 13, sensor_msgs::msg::PointField::UINT8);
      set_field(5, "channel", 14, sensor_msgs::msg::PointField::UINT16);
      out.data.resize(static_cast<std::size_t>(out.row_step) * out.height);

      for (std::uint32_t row = 0; row < in.height; ++row) {
        for (std::uint32_t col = 0; col < in.width; ++col) {
          const auto * src = in.data.data() + static_cast<std::size_t>(row) * in.row_step +
            static_cast<std::size_t>(col) * in.point_step;
          auto * dst = out.data.data() + static_cast<std::size_t>(row) * out.row_step +
            static_cast<std::size_t>(col) * out.point_step;
          std::memcpy(dst + 0, src + fx.offset, sizeof(float));
          std::memcpy(dst + 4, src + fy.offset, sizeof(float));
          std::memcpy(dst + 8, src + fz.offset, sizeof(float));
          float intensity = 0.0F;
          std::memcpy(&intensity, src + fi.offset, sizeof(float));
          dst[12] = static_cast<std::uint8_t>(std::clamp(std::lround(intensity), 0L, 255L));
          dst[13] = 1U;  // SINGLE_STRONGEST; RS driver does not expose return type here.
          const std::uint16_t channel = 0U;  // RS driver PointXYZI does not expose ring/channel.
          std::memcpy(dst + 14, &channel, sizeof(channel));
        }
      }
      publishers_[index]->publish(std::move(out));
    } catch (const std::exception & e) {
      RCLCPP_ERROR_THROTTLE(get_logger(), *get_clock(), 5000, "Input conversion failed: %s", e.what());
    }
  }

  std::vector<rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr> publishers_;
  std::vector<rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr> subscriptions_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<XyziToXyzircNode>());
  rclcpp::shutdown();
  return 0;
}
