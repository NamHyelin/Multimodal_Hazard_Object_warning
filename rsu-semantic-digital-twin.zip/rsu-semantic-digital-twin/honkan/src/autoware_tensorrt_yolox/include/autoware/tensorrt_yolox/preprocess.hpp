// Copyright 2023 TIER IV, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef AUTOWARE__TENSORRT_YOLOX__PREPROCESS_HPP_
#define AUTOWARE__TENSORRT_YOLOX__PREPROCESS_HPP_

#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_runtime_api.h>

namespace autoware
{
namespace tensorrt_yolox
{
struct Roi
{
  int x;
  int y;
  int w;
  int h;
};

/**
 * @brief Optimized preprocessing including resize, letterbox, nhwc2nchw, toFloat and normalization
 * with batching for YOLOX on gpus
 * @param[out] dst processed image
 * @param[in] src image
 * @param[in] d_w width for output
 * @param[in] d_h height for output
 * @param[in] d_c channel for output
 * @param[in] s_w width for input
 * @param[in] s_h height for input
 * @param[in] s_c channel for input
 * @param[in] batch batch size
 * @param[in] norm normalization
 * @param[in] stream cuda stream
 */
extern void resize_bilinear_letterbox_nhwc_to_nchw32_batch_gpu(
  float * dst, unsigned char * src, int d_w, int d_h, int d_c, int s_w, int s_h, int s_c, int batch,
  float norm, cudaStream_t stream);

/**
 * @brief Optimized multi-scale preprocessing including crop, resize, letterbox, nhwc2nchw, toFloat
 * and normalization with batching for YOLOX on gpus
 * @param[out] dst processed image
 * @param[in] src image
 * @param[in] d_w width for output
 * @param[in] d_h height for output
 * @param[in] d_c channel for output
 * @param[in] s_w width for input
 * @param[in] s_h height for input
 * @param[in] s_c channel for input
 * @param[in] d_roi regions of interest for cropping
 * @param[in] batch batch size
 * @param[in] norm normalization
 * @param[in] stream cuda stream
 */
extern void multi_scale_resize_bilinear_letterbox_nhwc_to_nchw32_batch_gpu(
  float * dst, unsigned char * src, int d_w, int d_h, int d_c, Roi * d_roi, int s_w, int s_h,
  int s_c, int batch, float norm, cudaStream_t stream);

/**
 * @brief Argmax on GPU
 * @param[out] dst processed image
 * @param[in] src probability map
 * @param[in] d_w width for output
 * @param[in] d_h height for output
 * @param[in] s_w width for input
 * @param[in] s_h height for input
 * @param[in] s_c channel for input
 * @param[in] batch batch size
 * @param[in] stream cuda stream
 */
extern void argmax_gpu(
  unsigned char * dst, float * src, int d_w, int d_h, int s_w, int s_h, int s_c, int batch,
  cudaStream_t stream);
}  // namespace tensorrt_yolox
}  // namespace autoware
#endif  // AUTOWARE__TENSORRT_YOLOX__PREPROCESS_HPP_
