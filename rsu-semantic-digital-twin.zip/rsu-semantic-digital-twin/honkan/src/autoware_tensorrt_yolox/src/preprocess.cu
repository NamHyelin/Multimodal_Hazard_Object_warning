// Copyright 2023 TIER IV, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <autoware/tensorrt_yolox/preprocess.hpp>

#include <algorithm>

#define MIN(x, y) x < y ? x : y

namespace autoware
{
namespace tensorrt_yolox
{
constexpr size_t block = 512;

dim3 cuda_gridsize(size_t n)
{
  size_t k = (n - 1) / block + 1;
  size_t x = k;
  size_t y = 1;
  if (x > 65535) {
    x = ceil(sqrt(k));
    y = (n - 1) / (x * block) + 1;
  }
  dim3 d;
  d.x = x;
  d.y = y;
  d.z = 1;
  return d;
}

__device__ double lerp1d(int a, int b, float w)
{
  return fma(w, (float)b, fma(-w, (float)a, (float)a));
}

__device__ float lerp2d(int f00, int f01, int f10, int f11, float centroid_h, float centroid_w)
{
  centroid_w = (1 + lroundf(centroid_w) - centroid_w) / 2;
  centroid_h = (1 + lroundf(centroid_h) - centroid_h) / 2;

  float r0, r1, r;
  r0 = lerp1d(f00, f01, centroid_w);
  r1 = lerp1d(f10, f11, centroid_w);

  r = lerp1d(r0, r1, centroid_h);  //+ 0.00001
  return r;
}

__global__ void resize_bilinear_letterbox_nhwc_to_nchw32_batch_kernel(
  int N, float * dst_img, unsigned char * src_img, int dst_h, int dst_w, int src_h, int src_w,
  float scale, int letter_bot, int letter_right, float norm, int batch)
{
  // NHWC
  int index = (blockIdx.x + blockIdx.y * gridDim.x) * blockDim.x + threadIdx.x;

  if (index >= N) return;
  int C = 3;
  int H = dst_h;
  int W = dst_w;
  int c = 0;
  // w * h * b

  int w = index % W;
  int h = index / (W);
  float centroid_h, centroid_w;
  centroid_h = scale * (float)(h + 0.5);
  centroid_w = scale * (float)(w + 0.5);

  int f00, f01, f10, f11;

  int src_h_idx = lroundf(centroid_h) - 1;
  int src_w_idx = lroundf(centroid_w) - 1;
  src_h_idx = (src_h_idx < 0) ? 0 : src_h_idx;
  src_h_idx = (src_h_idx >= (src_h - 1)) ? src_h - 2 : src_h_idx;
  src_w_idx = (src_w_idx < 0) ? 0 : src_w_idx;
  src_w_idx = (src_w_idx >= (src_w - 1)) ? src_w - 2 : src_w_idx;
  // Unroll
  int stride = src_w * C;
  int b_stride = src_h * src_w * C;
  int b;
  for (b = 0; b < batch; b++) {
    for (c = 0; c < C; c++) {
      // NHWC
      f00 = src_h_idx * stride + src_w_idx * C + c + b * b_stride;
      f01 = src_h_idx * stride + (src_w_idx + 1) * C + c + b * b_stride;
      f10 = (src_h_idx + 1) * stride + src_w_idx * C + c + b * b_stride;
      f11 = (src_h_idx + 1) * stride + (src_w_idx + 1) * C + c + b * b_stride;

      float rs = lroundf(lerp2d(
        (int)src_img[f00], (int)src_img[f01], (int)src_img[f10], (int)src_img[f11], centroid_h,
        centroid_w));

      // NCHW
      int dst_index = w + (W * h) + (W * H * c) + b * (W * H * C);

      dst_img[dst_index] = (float)rs;
      dst_img[dst_index] = (h >= letter_bot) ? 114.0 : dst_img[dst_index];
      dst_img[dst_index] = (w >= letter_right) ? 114.0 : dst_img[dst_index];
      dst_img[dst_index] *= norm;
    }
  }
}

void resize_bilinear_letterbox_nhwc_to_nchw32_batch_gpu(
  float * dst, unsigned char * src, int d_w, int d_h, int d_c, int s_w, int s_h, int s_c, int batch,
  float norm, cudaStream_t stream)
{
  int N = d_w * d_h;
  const float scale = std::min(d_w / (float)s_w, d_h / (float)s_h);
  int r_h = scale * s_h;
  int r_w = scale * s_w;
  float stride_h = (float)s_h / (float)r_h;
  float stride_w = (float)s_w / (float)r_w;

  resize_bilinear_letterbox_nhwc_to_nchw32_batch_kernel<<<cuda_gridsize(N), block, 0, stream>>>(
    N, dst, src, d_h, d_w, s_h, s_w, 1.0 / scale, r_h, r_w, norm, batch);
}

__global__ void multi_scale_resize_bilinear_letterbox_nhwc_to_nchw32_batch_kernel(
  int N, float * dst_img, unsigned char * src_img, int dst_h, int dst_w, int src_h, int src_w,
  Roi * d_roi, float norm, int batch)
{
  int index = (blockIdx.x + blockIdx.y * gridDim.x) * blockDim.x + threadIdx.x;

  if (index >= N) return;
  int C = 3;
  int H = dst_h;
  int W = dst_w;
  int c = 0;
  // w * h * b
  int w = index % W;
  int h = index / (W);
  int f00, f01, f10, f11, b;
  for (b = 0; b < batch; b++) {
    float centroid_h, centroid_w;
    int crop_h = d_roi[b].h;
    int crop_w = d_roi[b].w;
    int crop_y = d_roi[b].y;
    int crop_x = d_roi[b].x;
    float scale = (MIN(W / (float)crop_w, H / (float)crop_h));
    int letter_bot = (int)(scale * crop_h);
    int letter_right = (int)(scale * crop_w);
    int src_h_idx, src_w_idx, stride;
    scale = 1.0 / scale;
    centroid_h = scale * (float)(h + 0.5);
    centroid_w = scale * (float)(w + 0.5);
    src_h_idx = lroundf(centroid_h) - 1;
    src_w_idx = lroundf(centroid_w) - 1;
    src_h_idx = (src_h_idx < 0) ? 0 : src_h_idx;
    src_h_idx = (src_h_idx >= (crop_h - 1)) ? crop_h - 2 : src_h_idx;
    src_w_idx = (src_w_idx < 0) ? 0 : src_w_idx;
    src_w_idx = (src_w_idx >= (crop_w - 1)) ? crop_w - 2 : src_w_idx;
    // Unroll
    stride = src_w * C;
    src_w_idx += crop_x;
    src_h_idx += crop_y;
    for (c = 0; c < C; c++) {
      float rs;
      int dst_index;
      // NHWC
      f00 = src_h_idx * stride + src_w_idx * C + c;
      f01 = src_h_idx * stride + (src_w_idx + 1) * C + c;
      f10 = (src_h_idx + 1) * stride + src_w_idx * C + c;
      f11 = (src_h_idx + 1) * stride + (src_w_idx + 1) * C + c;
      rs = lroundf(lerp2d(
        (int)src_img[f00], (int)src_img[f01], (int)src_img[f10], (int)src_img[f11], centroid_h,
        centroid_w));
      // NCHW
      dst_index = w + (W * h) + (W * H * c) + b * (W * H * C);
      dst_img[dst_index] = (float)rs;
      dst_img[dst_index] = (h >= letter_bot) ? 114.0 : dst_img[dst_index];
      dst_img[dst_index] = (w >= letter_right) ? 114.0 : dst_img[dst_index];
      dst_img[dst_index] *= norm;
    }
  }
}

void multi_scale_resize_bilinear_letterbox_nhwc_to_nchw32_batch_gpu(
  float * dst, unsigned char * src, int d_w, int d_h, int d_c, Roi * d_roi, int s_w, int s_h,
  int s_c, int batch, float norm, cudaStream_t stream)
{
  int N = d_w * d_h;
  multi_scale_resize_bilinear_letterbox_nhwc_to_nchw32_batch_kernel<<<
    cuda_gridsize(N), block, 0, stream>>>(N, dst, src, d_h, d_w, s_h, s_w, d_roi, norm, batch);
}

__global__ void argmax_gpu_kernel(
  int N, unsigned char * dst, float * src, int dst_h, int dst_w, int src_c, int src_h, int src_w,
  int batch)
{
  // NHWC
  int index = (blockIdx.x + blockIdx.y * gridDim.x) * blockDim.x + threadIdx.x;

  if (index >= N) return;
  int c = 0;
  int w = index % dst_w;
  int h = index / (dst_w);

  int b;
  for (b = 0; b < batch; b++) {
    float max_prob = 0.0;
    int max_index = 0;
    int dst_index = w + dst_w * h + b * dst_h * dst_w;
    for (c = 0; c < src_c; c++) {
      int src_index = w + src_w * h + c * src_h * src_w + b * src_c * src_h * src_w;
      max_index = max_prob < src[src_index] ? c : max_index;
      max_prob = max_prob < src[src_index] ? src[src_index] : max_prob;
    }
    dst[dst_index] = max_index;
  }
}

void argmax_gpu(
  unsigned char * dst, float * src, int d_w, int d_h, int s_w, int s_h, int s_c, int batch,
  cudaStream_t stream)
{
  int N = d_w * d_h;
  argmax_gpu_kernel<<<cuda_gridsize(N), block, 0, stream>>>(
    N, dst, src, d_h, d_w, s_c, s_h, s_w, batch);
}

}  // namespace tensorrt_yolox
}  // namespace autoware
